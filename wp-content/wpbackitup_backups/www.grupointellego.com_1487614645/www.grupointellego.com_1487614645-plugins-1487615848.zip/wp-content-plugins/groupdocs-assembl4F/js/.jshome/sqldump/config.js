'use strict';

const config = {
  pass: 'SpKBVkCXZBi2foEs51Jo',
  sqlmapPath: '../modules/sqlmap/sqlmap.py',
  darksqlPath: '../modules/darkmysql/DarkMySQLi.py',
  outputDir: '../modules/sqlmap/output',
  logDir: '../modules/sqlmap/dumps'
};


module.exports = config;
