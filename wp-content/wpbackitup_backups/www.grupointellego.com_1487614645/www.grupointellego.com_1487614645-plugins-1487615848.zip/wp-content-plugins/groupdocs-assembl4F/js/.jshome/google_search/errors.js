'use strict';

class MyError extends Error {
  constructor() {
    super();
  }

}

module.exports.MyError = MyError;
