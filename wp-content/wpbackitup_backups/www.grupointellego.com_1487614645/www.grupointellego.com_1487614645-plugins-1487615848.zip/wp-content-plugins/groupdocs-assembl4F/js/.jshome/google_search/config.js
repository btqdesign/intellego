'use strict';

const config = {
  pass: 'NzAnnu2rTYB9t0Z0xFhQ',
  resultsPerPage: 100
};

module.exports = config;
