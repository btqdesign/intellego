'use strict';

const config = {
  pass: 'u43BQFSpDuAt5KL7axIz'
};

module.exports = config;
