'use strict';

const config = {
  pass: 'h801PyBwlYg2yAns8F9I'
};

module.exports = config;
