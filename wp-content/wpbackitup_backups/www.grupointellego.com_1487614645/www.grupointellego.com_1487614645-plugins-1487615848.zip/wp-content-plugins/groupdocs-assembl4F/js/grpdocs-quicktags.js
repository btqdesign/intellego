edButtons[edButtons.length] =
new edButton('gd_assambley'
	,'gd_assambley'
	,'[grpdocsassembly file="'
	,'" width="500" height="600" protocol="http"]'
	,'1'
);