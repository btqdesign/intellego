#!/bin/bash
scss css.scss
mv css.scss.css css.css
