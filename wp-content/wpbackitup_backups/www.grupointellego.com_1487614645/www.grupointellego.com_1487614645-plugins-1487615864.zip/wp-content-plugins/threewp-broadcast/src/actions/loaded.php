<?php

namespace threewp_broadcast\actions;

/**
	@brief		Broadcast is loaded and ready for action.
	@details	Now would be a good time for the plugin packs to load.
	@since		2015-10-29 12:21:37
**/
class loaded
	extends action
{
}
