<?php

namespace threewp_broadcast\actions;

/**
	@brief		The plugin pack is being uninstalled. Plugin packs should uninstall their settings now.
	@since		2015-10-28 15:08:49
**/
class plugin_pack_uninstall
	extends action
{
}
