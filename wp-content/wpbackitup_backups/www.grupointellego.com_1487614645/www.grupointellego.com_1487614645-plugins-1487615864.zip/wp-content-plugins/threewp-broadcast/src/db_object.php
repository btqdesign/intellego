<?php

namespace threewp_broadcast;

class db_object
{
	use \plainview\sdk_broadcast\wordpress\traits\db_aware_object;
	use \plainview\sdk_broadcast\traits\method_chaining;
}
