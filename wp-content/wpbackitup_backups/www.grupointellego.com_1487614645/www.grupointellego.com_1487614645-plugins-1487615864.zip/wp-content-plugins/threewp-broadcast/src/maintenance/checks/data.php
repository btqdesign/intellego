<?php

namespace threewp_broadcast\maintenance\checks;

/**
	@brief		Data object for a check.
	@since		20131104
**/
class data
{
}
