<?php
    // placeholder for Settings template page
?>