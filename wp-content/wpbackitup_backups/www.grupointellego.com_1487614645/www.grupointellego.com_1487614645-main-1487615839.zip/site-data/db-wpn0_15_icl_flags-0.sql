-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:22
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_15_icl_flags
-- Snapshot Table  : 1487614645_15_icl_flags
--
-- SQL    : SELECT * FROM wpn0_15_icl_flags LIMIT 0,10000
-- Offset : 0
-- Rows   : 64
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_15_icl_flags`
--
DROP TABLE  IF EXISTS `1487614645_15_icl_flags`;
CREATE TABLE `1487614645_15_icl_flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang_code` varchar(10) NOT NULL,
  `flag` varchar(32) NOT NULL,
  `from_template` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `lang_code` (`lang_code`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_15_icl_flags`
-- Number of rows: 64
--
INSERT INTO `1487614645_15_icl_flags` VALUES 
(1,'ar','ar.png',0),
 (2,'bg','bg.png',0),
 (3,'bs','bs.png',0),
 (4,'ca','ca.png',0),
 (5,'cs','cs.png',0),
 (6,'cy','cy.png',0),
 (7,'da','da.png',0),
 (8,'de','de.png',0),
 (9,'el','el.png',0),
 (10,'en','en.png',0),
 (11,'eo','eo.png',0),
 (12,'es','es.png',0),
 (13,'et','et.png',0),
 (14,'eu','eu.png',0),
 (15,'fa','fa.png',0),
 (16,'fi','fi.png',0),
 (17,'fr','fr.png',0),
 (18,'ga','ga.png',0),
 (19,'he','he.png',0),
 (20,'hi','hi.png',0),
 (21,'hr','hr.png',0),
 (22,'hu','hu.png',0),
 (23,'hy','hy.png',0),
 (24,'id','id.png',0),
 (25,'is','is.png',0),
 (26,'it','it.png',0),
 (27,'ja','ja.png',0),
 (28,'ko','ko.png',0),
 (29,'ku','ku.png',0),
 (30,'la','la.png',0),
 (31,'lt','lt.png',0),
 (32,'lv','lv.png',0),
 (33,'mk','mk.png',0),
 (34,'mn','mn.png',0),
 (35,'mo','mo.png',0),
 (36,'ms','ms.png',0),
 (37,'mt','mt.png',0),
 (38,'nb','nb.png',0),
 (39,'ne','ne.png',0),
 (40,'nl','nl.png',0),
 (41,'pa','pa.png',0),
 (42,'pl','pl.png',0),
 (43,'pt-br','pt-br.png',0),
 (44,'pt-pt','pt-pt.png',0),
 (45,'qu','qu.png',0),
 (46,'ro','ro.png',0),
 (47,'ru','ru.png',0),
 (48,'sk','sk.png',0),
 (49,'sl','sl.png',0),
 (50,'so','so.png',0),
 (51,'sq','sq.png',0),
 (52,'sr','sr.png',0),
 (53,'sv','sv.png',0),
 (54,'ta','ta.png',0),
 (55,'th','th.png',0),
 (56,'tr','tr.png',0),
 (57,'uk','uk.png',0),
 (58,'ur','ur.png',0),
 (59,'uz','uz.png',0),
 (60,'vi','vi.png',0),
 (61,'yi','yi.png',0),
 (62,'zh-hans','zh-hans.png',0),
 (63,'zh-hant','zh-hant.png',0),
 (64,'zu','zu.png',0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
