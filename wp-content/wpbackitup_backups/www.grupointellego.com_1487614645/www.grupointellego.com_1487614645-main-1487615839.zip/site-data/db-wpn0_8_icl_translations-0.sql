-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:21
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_8_icl_translations
-- Snapshot Table  : 1487614645_8_icl_translations
--
-- SQL    : SELECT * FROM wpn0_8_icl_translations LIMIT 0,10000
-- Offset : 0
-- Rows   : 127
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_8_icl_translations`
--
DROP TABLE  IF EXISTS `1487614645_8_icl_translations`;
CREATE TABLE `1487614645_8_icl_translations` (
  `translation_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `element_type` varchar(36) NOT NULL DEFAULT 'post_post',
  `element_id` bigint(20) DEFAULT NULL,
  `trid` bigint(20) NOT NULL,
  `language_code` varchar(7) NOT NULL,
  `source_language_code` varchar(7) DEFAULT NULL,
  PRIMARY KEY (`translation_id`),
  UNIQUE KEY `trid_lang` (`trid`,`language_code`),
  UNIQUE KEY `el_type_id` (`element_type`,`element_id`),
  KEY `trid` (`trid`),
  KEY `id_type_language` (`element_id`,`element_type`,`language_code`)
) ENGINE=InnoDB AUTO_INCREMENT=299 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_8_icl_translations`
-- Number of rows: 127
--
INSERT INTO `1487614645_8_icl_translations` VALUES 
(32,'post_post',1,1,'es',NULL),
 (33,'post_wpcf7_contact_form',3421,3421,'es',NULL),
 (64,'tax_category',1,3454,'es',NULL),
 (65,'tax_category',7,3460,'es',NULL),
 (66,'tax_category',9,3462,'es',NULL),
 (67,'tax_category',11,3464,'es',NULL),
 (68,'tax_category',13,3466,'es',NULL),
 (69,'tax_category',15,3468,'es',NULL),
 (70,'tax_category',17,3470,'es',NULL),
 (71,'tax_category',19,3472,'es',NULL),
 (79,'tax_post_tag',21,3494,'es',NULL),
 (80,'tax_post_tag',23,3496,'es',NULL),
 (81,'tax_post_tag',25,3498,'es',NULL),
 (82,'tax_post_tag',27,3500,'es',NULL),
 (83,'tax_post_tag',29,3502,'es',NULL),
 (86,'tax_nav_menu',8,3511,'es',NULL),
 (87,'tax_nav_menu',39,3542,'es',NULL),
 (96,'comment',1,3582,'es',NULL),
 (97,'tax_member-category',31,3583,'es',NULL),
 (98,'tax_member-category',33,3584,'es',NULL),
 (99,'tax_member-category',35,3585,'es',NULL),
 (100,'tax_member-category',37,3586,'es',NULL),
 (101,'post_post',3458,1,'en','es'),
 (102,'post_post',3459,3587,'es',NULL),
 (103,'post_page',3463,3588,'es',NULL),
 (105,'post_post',3464,3589,'es',NULL),
 (106,'tax_category',40,3590,'es',NULL),
 (108,'post_post',3467,3591,'es',NULL),
 (110,'post_post',3468,3592,'es',NULL),
 (112,'post_page',3488,3594,'es',NULL),
 (114,'post_page',3495,3595,'es',NULL),
 (115,'post_nav_menu_item',3423,3596,'es',NULL),
 (116,'post_nav_menu_item',3424,3597,'es',NULL),
 (117,'post_nav_menu_item',3425,3598,'es',NULL),
 (118,'post_nav_menu_item',3426,3599,'es',NULL),
 (119,'post_nav_menu_item',3427,3600,'es',NULL),
 (120,'post_nav_menu_item',3428,3601,'es',NULL),
 (153,'post_page',3499,3627,'es',NULL),
 (155,'post_page',3501,3628,'es',NULL),
 (157,'post_page',3505,3629,'es',NULL),
 (159,'post_nav_menu_item',3511,3631,'es',NULL),
 (160,'post_nav_menu_item',3512,3632,'es',NULL),
 (161,'post_nav_menu_item',3513,3633,'es',NULL),
 (162,'post_nav_menu_item',3514,3634,'es',NULL),
 (164,'post_page',3517,3636,'es',NULL),
 (166,'post_page',3522,3637,'es',NULL),
 (168,'post_page',3524,3638,'es',NULL),
 (170,'post_page',3529,3639,'es',NULL),
 (172,'post_page',3532,3640,'es',NULL),
 (174,'post_page',3535,3641,'es',NULL),
 (176,'post_page',3538,3642,'es',NULL),
 (178,'post_page',3543,3643,'es',NULL),
 (180,'post_page',3546,3644,'es',NULL),
 (182,'post_page',3551,3645,'es',NULL),
 (183,'post_nav_menu_item',3552,3646,'es',NULL),
 (184,'post_nav_menu_item',3553,3647,'es',NULL),
 (185,'post_nav_menu_item',3554,3648,'es',NULL),
 (186,'post_nav_menu_item',3555,3649,'es',NULL),
 (187,'post_nav_menu_item',3556,3650,'es',NULL),
 (188,'post_nav_menu_item',3557,3651,'es',NULL),
 (189,'post_nav_menu_item',3558,3652,'es',NULL),
 (190,'post_nav_menu_item',3559,3653,'es',NULL),
 (192,'post_page',3561,3654,'es',NULL),
 (193,'post_nav_menu_item',3563,3655,'es',NULL),
 (196,'post_post',3580,3657,'es',NULL),
 (198,'post_post',3585,3658,'es',NULL),
 (200,'post_post',3586,3659,'es',NULL),
 (202,'post_post',3588,3660,'es',NULL),
 (204,'post_page',3589,3661,'es',NULL),
 (206,'post_page',3592,3662,'es',NULL),
 (208,'post_page',3594,3663,'es',NULL),
 (210,'post_page',3595,3664,'es',NULL),
 (215,'post_page',3602,3667,'es',NULL),
 (219,'post_page',3609,3669,'es',NULL),
 (221,'post_page',3610,3670,'es',NULL),
 (222,'post_page',3611,3671,'es',NULL),
 (223,'post_page',3612,3672,'es',NULL),
 (225,'post_page',3613,3673,'es',NULL),
 (226,'post_page',3614,3674,'es',NULL),
 (227,'post_page',3615,3675,'es',NULL),
 (230,'post_page',3616,3678,'es',NULL),
 (233,'post_nav_menu_item',3620,3681,'es',NULL),
 (234,'post_nav_menu_item',3621,3682,'es',NULL),
 (235,'post_nav_menu_item',3622,3683,'es',NULL),
 (236,'post_nav_menu_item',3623,3684,'es',NULL),
 (237,'post_nav_menu_item',3624,3685,'es',NULL),
 (238,'post_nav_menu_item',3625,3686,'es',NULL),
 (239,'post_nav_menu_item',3626,3687,'es',NULL),
 (240,'post_nav_menu_item',3627,3688,'es',NULL),
 (244,'post_page',3644,3690,'es',NULL),
 (245,'post_project',3646,3691,'es',NULL),
 (246,'post_project',3648,3692,'es',NULL),
 (247,'post_project',3647,3693,'es',NULL),
 (248,'post_project',3482,3694,'es',NULL),
 (249,'post_project',3484,3695,'es',NULL),
 (250,'post_project',3487,3696,'es',NULL),
 (251,'post_project',3474,3697,'es',NULL),
 (252,'post_page',3649,3698,'es',NULL),
 (254,'post_project',3651,3699,'es',NULL),
 (258,'post_project',3654,3703,'es',NULL),
 (259,'post_page',3653,3704,'es',NULL),
 (261,'post_page',3656,3705,'es',NULL),
 (263,'post_page',3658,3706,'es',NULL),
 (265,'post_page',3660,3707,'es',NULL),
 (267,'post_page',3659,3708,'es',NULL),
 (269,'post_page',3661,3709,'es',NULL),
 (271,'post_page',3663,3710,'es',NULL),
 (272,'post_nav_menu_item',3664,3711,'es',NULL),
 (273,'post_nav_menu_item',3665,3712,'es',NULL),
 (274,'post_nav_menu_item',3666,3713,'es',NULL),
 (275,'post_nav_menu_item',3667,3714,'es',NULL),
 (276,'post_nav_menu_item',3668,3715,'es',NULL),
 (277,'post_nav_menu_item',3669,3716,'es',NULL),
 (278,'post_nav_menu_item',3670,3717,'es',NULL),
 (279,'post_nav_menu_item',3671,3718,'es',NULL),
 (280,'post_nav_menu_item',3672,3719,'es',NULL),
 (285,'post_page',3678,3722,'es',NULL),
 (288,'post_page',3682,3724,'es',NULL),
 (289,'post_nav_menu_item',3683,3725,'es',NULL),
 (290,'post_nav_menu_item',3684,3726,'es',NULL),
 (291,'post_nav_menu_item',3685,3727,'es',NULL),
 (293,'post_project',3686,3728,'es',NULL),
 (294,'tax_nav_menu',47,3729,'es',NULL),
 (295,'post_nav_menu_item',3695,3730,'es',NULL),
 (296,'post_nav_menu_item',3696,3731,'es',NULL),
 (297,'post_nav_menu_item',3697,3732,'es',NULL),
 (298,'post_nav_menu_item',3698,3733,'es',NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
