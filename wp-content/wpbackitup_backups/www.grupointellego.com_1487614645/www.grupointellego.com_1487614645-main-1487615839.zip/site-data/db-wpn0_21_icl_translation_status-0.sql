-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:27
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_21_icl_translation_status
-- Snapshot Table  : 1487614645_21_icl_translation_status
--
-- SQL    : SELECT * FROM wpn0_21_icl_translation_status LIMIT 0,10000
-- Offset : 0
-- Rows   : 1
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_21_icl_translation_status`
--
DROP TABLE  IF EXISTS `1487614645_21_icl_translation_status`;
CREATE TABLE `1487614645_21_icl_translation_status` (
  `rid` bigint(20) NOT NULL AUTO_INCREMENT,
  `translation_id` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `translator_id` bigint(20) NOT NULL,
  `needs_update` tinyint(4) NOT NULL,
  `md5` varchar(32) NOT NULL,
  `translation_service` varchar(16) NOT NULL,
  `translation_package` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `links_fixed` tinyint(4) NOT NULL DEFAULT '0',
  `_prevstate` longtext,
  PRIMARY KEY (`rid`),
  UNIQUE KEY `translation_id` (`translation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_21_icl_translation_status`
-- Number of rows: 1
--
INSERT INTO `1487614645_21_icl_translation_status` VALUES 
(1,101,0,0,1,'a6a7bcb19b4cd58012a7b25a120fac25','','a:2:{s:3:\"url\";s:34:\"http://www.grupointellego.com/-2?p=1\";s:8:\"contents\";a:5:{s:5:\"title\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:20:\"wqFIb2xhIG11bmRvIQ==\";s:6:\"format\";s:6:\"base64\";}s:4:\"body\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:132:\"QmllbnZlbmlkbyBhIFdvcmRQcmVzcy4gRXN0YSBlcyB0dSBwcmltZXJhIGVudHJhZGEuIEVkw610YWxhIG8gYsOzcnJhbGEsIMKheSBjb21pZW56YSBhIHB1YmxpY2FyIS4=\";s:6:\"format\";s:6:\"base64\";}s:11:\"original_id\";a:2:{s:9:\"translate\";i:0;s:4:\"data\";i:1;}s:10:\"categories\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:22:\"\"U2luIGNhdGVnb3LDrWE=\"\";s:6:\"format\";s:10:\"csv_base64\";}s:12:\"category_ids\";a:2:{s:9:\"translate\";i:0;s:4:\"data\";s:1:\"1\";}}}','2015-03-23 16:43:18',0,NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
