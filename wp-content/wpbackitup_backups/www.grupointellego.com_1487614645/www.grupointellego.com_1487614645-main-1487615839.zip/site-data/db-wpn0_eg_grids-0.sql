-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:27
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_eg_grids
-- Snapshot Table  : 1487614645_eg_grids
--
-- SQL    : SELECT * FROM wpn0_eg_grids LIMIT 0,10000
-- Offset : 0
-- Rows   : 1
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_eg_grids`
--
DROP TABLE  IF EXISTS `1487614645_eg_grids`;
CREATE TABLE `1487614645_eg_grids` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `postparams` text NOT NULL,
  `params` text NOT NULL,
  `layers` mediumtext NOT NULL,
  `settings` text,
  `last_modified` datetime DEFAULT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `handle` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_eg_grids`
-- Number of rows: 1
--
INSERT INTO `1487614645_eg_grids` VALUES 
(1,'valores','val','{\"source-type\":\"custom\",\"post_types\":\"post\",\"post_category\":\"\",\"additional-query\":\"\",\"selected_pages\":\"\",\"max_entries\":\"-1\",\"media-source-order\":[\"youtube\"],\"default-image\":\"0\",\"image-source-type\":\"full\"}','{\"layout-sizing\":\"boxed\",\"fullscreen-offset-container\":\"\",\"layout\":\"even\",\"content-push\":\"off\",\"x-ratio\":\"4\",\"y-ratio\":\"3\",\"rtl\":\"off\",\"use-cobbles-pattern\":\"off\",\"columns-advanced\":\"off\",\"columns-height\":[\"0\",\"0\",\"0\",\"0\",\"0\",\"0\",\"0\"],\"columns-width\":[\"1400\",\"1170\",\"1024\",\"960\",\"778\",\"640\",\"480\"],\"columns\":[\"5\",\"4\",\"4\",\"3\",\"3\",\"3\",\"1\"],\"rows-unlimited\":\"off\",\"rows\":\"3\",\"load-more\":\"none\",\"load-more-text\":\"Load More\",\"load-more-show-number\":\"on\",\"load-more-start\":\"3\",\"load-more-amount\":\"3\",\"lazy-loading\":\"off\",\"lazy-load-color\":\"#FFFFFF\",\"0\":\"\",\"spacings\":\"0\",\"grid-padding\":[\"0\",\"0\",\"0\",\"0\"],\"main-background-color\":\"transparent\",\"navigation-skin\":\"minimal-light\",\"entry-skin\":\"1\",\"grid-animation\":\"fade\",\"grid-animation-speed\":\"1000\",\"grid-animation-delay\":\"1\",\"hover-animation-delay\":\"1\",\"top-1-align\":\"center\",\"top-1-margin-bottom\":\"0\",\"top-2-align\":\"center\",\"top-2-margin-bottom\":\"0\",\"bottom-1-align\":\"center\",\"bottom-1-margin-top\":\"0\",\"bottom-2-align\":\"center\",\"bottom-2-margin-top\":\"0\",\"left-margin-left\":\"0\",\"right-margin-right\":\"0\",\"module-spacings\":\"5\",\"pagination-scroll\":\"off\",\"pagination-scroll-offset\":\"0\",\"filter-arrows\":\"single\",\"filter-logic\":\"or\",\"filter-start\":\"\",\"filter-show-on\":\"hover\",\"filter-all-text\":\"Filter - All\",\"filter-listing\":\"list\",\"filter-dropdown-text\":\"Filter Categories\",\"filter-counter\":\"off\",\"sort-by-text\":\"Sort By \",\"sorting-order-by\":\"date\",\"sorting-order-by-start\":\"none\",\"sorting-order-by-start-meta\":\"\",\"sorting-order-type\":\"ASC\",\"search-text\":\"Search...\",\"poster-source-order\":[\"featured-image\"],\"lb-source-order\":[\"featured-image\"],\"lightbox-mode\":\"single\",\"lightbox-exclude-media\":\"off\",\"lightbox-type\":\"null\",\"lightbox-position\":\"bottom\",\"lightbox-twitter\":\"off\",\"lightbox-facebook\":\"off\",\"lbox-inpadding\":[\"0\",\"0\",\"0\",\"0\"],\"lbox-padding\":[\"0\",\"0\",\"0\",\"0\"],\"lightbox-effect-open-close\":\"fade\",\"lightbox-effect-open-close-speed\":\"normal\",\"lightbox-effect-next-prev\":\"fade\",\"lightbox-effect-next-prev-speed\":\"normal\",\"lightbox-arrows\":\"on\",\"lightbox-thumbs\":\"off\",\"lbox-thumb-w\":\"50\",\"lbox-thumb-h\":\"50\",\"aj-source-order\":[\"post-content\"],\"ajax-container-id\":\"ess-grid-ajax-container-\",\"ajax-container-position\":\"top\",\"ajax-scroll-onload\":\"on\",\"ajax-scrollto-offset\":\"0\",\"ajax-close-button\":\"off\",\"ajax-button-text\":\"Close\",\"ajax-nav-button\":\"off\",\"ajax-button-skin\":\"light\",\"ajax-button-type\":\"type1\",\"ajax-button-inner\":\"false\",\"ajax-button-h-pos\":\"r\",\"ajax-button-v-pos\":\"t\",\"ajax-container-pre\":\"\",\"ajax-container-post\":\"\",\"ajax-container-css\":\"\",\"ajax-callback\":\"\",\"ajax-callback-arg\":\"true\",\"ajax-css-url\":\"\",\"ajax-js-url\":\"\",\"use-spinner\":\"0\",\"spinner-color\":\"#FFFFFF\",\"hide-markup-before-load\":\"off\",\"custom-javascript\":\"\",\"css-id\":\"valores\"}','[\"{\\\"custom-type\\\":\\\"youtube\\\",\\\"custom-youtube\\\":\\\"https:\\\\\\/\\\\\\/youtu.be\\\\\\/1Wj3S2DmLVo\\\",\\\"custom-ratio\\\":\\\"0\\\",\\\"cobbles-size\\\":\\\"1:1\\\",\\\"use-skin\\\":\\\"-1\\\"}\"]',NULL,'2015-07-01 18:15:33');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
