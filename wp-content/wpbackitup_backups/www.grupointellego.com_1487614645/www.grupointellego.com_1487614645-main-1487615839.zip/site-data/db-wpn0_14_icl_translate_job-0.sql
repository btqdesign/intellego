-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:23
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_14_icl_translate_job
-- Snapshot Table  : 1487614645_14_icl_translate_job
--
-- SQL    : SELECT * FROM wpn0_14_icl_translate_job LIMIT 0,10000
-- Offset : 0
-- Rows   : 44
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_14_icl_translate_job`
--
DROP TABLE  IF EXISTS `1487614645_14_icl_translate_job`;
CREATE TABLE `1487614645_14_icl_translate_job` (
  `job_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rid` bigint(20) unsigned NOT NULL,
  `translator_id` int(10) unsigned NOT NULL,
  `translated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `manager_id` int(10) unsigned NOT NULL,
  `revision` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`job_id`),
  KEY `rid` (`rid`,`translator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_14_icl_translate_job`
-- Number of rows: 44
--
INSERT INTO `1487614645_14_icl_translate_job` VALUES 
(1,1,0,0,1,NULL),
 (2,2,5,1,5,1),
 (3,2,5,1,5,NULL),
 (4,3,5,1,5,NULL),
 (5,4,5,1,5,1),
 (6,4,5,1,5,2),
 (7,4,5,1,3,3),
 (8,4,3,1,5,4),
 (9,4,5,1,3,NULL),
 (10,5,5,1,5,NULL),
 (11,6,5,1,5,NULL),
 (12,7,5,1,5,NULL),
 (13,8,5,1,5,1),
 (14,9,5,1,5,1),
 (15,10,5,1,5,1),
 (16,11,5,1,5,NULL),
 (17,12,5,1,5,NULL),
 (18,13,5,1,5,NULL),
 (19,14,5,1,5,NULL),
 (20,15,5,1,5,1),
 (21,15,5,1,5,NULL),
 (22,16,5,1,5,NULL),
 (23,17,5,1,5,1),
 (24,17,5,1,5,2),
 (25,17,5,1,5,NULL),
 (26,18,5,1,5,NULL),
 (27,19,5,1,5,NULL),
 (28,20,5,1,5,NULL),
 (29,21,5,1,5,1),
 (30,22,5,1,5,1),
 (31,22,5,1,5,NULL),
 (32,23,5,1,5,NULL),
 (33,24,5,1,5,1),
 (34,24,5,1,5,NULL),
 (35,25,5,1,5,1),
 (36,26,5,1,5,1),
 (37,27,5,1,5,NULL),
 (38,28,5,1,5,NULL),
 (39,25,5,1,5,NULL),
 (40,21,5,1,5,NULL),
 (41,26,5,1,5,NULL),
 (42,9,5,1,5,NULL),
 (43,10,5,1,5,NULL),
 (44,8,5,1,5,NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
