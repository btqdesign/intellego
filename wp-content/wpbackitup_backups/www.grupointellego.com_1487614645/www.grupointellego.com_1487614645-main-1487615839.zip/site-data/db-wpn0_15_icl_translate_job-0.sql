-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:23
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_15_icl_translate_job
-- Snapshot Table  : 1487614645_15_icl_translate_job
--
-- SQL    : SELECT * FROM wpn0_15_icl_translate_job LIMIT 0,10000
-- Offset : 0
-- Rows   : 54
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_15_icl_translate_job`
--
DROP TABLE  IF EXISTS `1487614645_15_icl_translate_job`;
CREATE TABLE `1487614645_15_icl_translate_job` (
  `job_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rid` bigint(20) unsigned NOT NULL,
  `translator_id` int(10) unsigned NOT NULL,
  `translated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `manager_id` int(10) unsigned NOT NULL,
  `revision` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`job_id`),
  KEY `rid` (`rid`,`translator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_15_icl_translate_job`
-- Number of rows: 54
--
INSERT INTO `1487614645_15_icl_translate_job` VALUES 
(1,1,0,0,1,NULL),
 (2,2,5,1,5,1),
 (3,2,5,1,5,2),
 (4,3,5,1,5,1),
 (5,3,5,1,5,NULL),
 (6,4,5,1,5,1),
 (7,4,5,1,5,NULL),
 (8,5,5,1,5,NULL),
 (9,6,5,1,5,1),
 (10,6,5,1,5,NULL),
 (11,7,5,1,5,1),
 (12,7,5,1,5,NULL),
 (13,8,5,1,5,1),
 (14,8,5,1,5,NULL),
 (15,2,5,1,3,3),
 (16,2,3,1,5,4),
 (17,2,5,1,3,5),
 (18,2,5,1,5,NULL),
 (19,9,5,1,5,NULL),
 (20,10,5,1,5,NULL),
 (21,11,5,1,5,NULL),
 (22,12,5,1,5,1),
 (23,13,5,1,5,1),
 (24,14,5,1,5,1),
 (25,15,5,1,5,1),
 (26,15,5,1,5,NULL),
 (27,16,5,1,5,NULL),
 (28,17,5,1,5,1),
 (29,18,5,1,5,NULL),
 (30,19,5,1,5,NULL),
 (31,20,5,1,5,NULL),
 (32,21,5,1,5,NULL),
 (33,22,5,1,5,NULL),
 (34,23,5,1,5,NULL),
 (35,24,5,1,5,1),
 (36,25,5,1,5,1),
 (37,26,5,1,5,NULL),
 (38,27,5,1,5,NULL),
 (39,28,5,1,5,NULL),
 (40,17,5,0,5,NULL),
 (43,14,5,1,5,NULL),
 (45,30,5,1,5,NULL),
 (46,31,5,1,5,1),
 (47,31,5,1,5,NULL),
 (48,32,5,1,5,NULL),
 (49,33,5,1,5,1),
 (50,33,5,1,5,NULL),
 (51,34,5,1,5,NULL),
 (52,35,5,1,5,NULL),
 (53,36,5,1,5,NULL),
 (54,24,5,1,5,NULL),
 (55,25,5,1,5,NULL),
 (56,12,5,0,5,NULL),
 (57,13,5,0,5,NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
