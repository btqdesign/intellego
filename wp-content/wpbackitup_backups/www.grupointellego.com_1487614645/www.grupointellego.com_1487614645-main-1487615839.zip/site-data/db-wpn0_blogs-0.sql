-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:24
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_blogs
-- Snapshot Table  : 1487614645_blogs
--
-- SQL    : SELECT * FROM wpn0_blogs LIMIT 0,10000
-- Offset : 0
-- Rows   : 10
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_blogs`
--
DROP TABLE  IF EXISTS `1487614645_blogs`;
CREATE TABLE `1487614645_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `last_updated` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` tinyint(2) NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_blogs`
-- Number of rows: 10
--
INSERT INTO `1487614645_blogs` VALUES 
(1,1,'www.grupointellego.com','/','2015-03-16 23:01:53','2017-01-05 16:01:27',1,0,0,0,0,0),
 (12,1,'www.grupointellego.com','/mx/','2015-04-16 20:14:15','2016-08-18 13:45:41',1,0,0,0,0,0),
 (13,1,'www.grupointellego.com','/us/','2015-04-17 01:15:22','2016-03-22 19:33:32',1,0,0,0,0,0),
 (14,1,'www.grupointellego.com','/centroamerica/','2015-04-17 01:16:21','2016-08-18 13:37:18',1,0,0,0,0,0),
 (15,1,'www.grupointellego.com','/co/','2015-04-17 01:17:11','2016-08-10 15:03:24',1,0,0,0,0,0),
 (16,1,'www.grupointellego.com','/ec/','2015-04-17 01:18:37','2016-03-22 19:35:45',1,0,0,0,0,0),
 (17,1,'www.grupointellego.com','/pe/','2015-04-17 01:19:19','2016-03-22 19:35:45',1,0,0,0,0,0),
 (18,1,'www.grupointellego.com','/br/','2015-04-17 01:20:13','2016-03-22 19:33:30',1,0,0,0,0,0),
 (19,1,'www.grupointellego.com','/cl/','2015-04-17 01:21:17','2016-08-10 15:03:25',1,0,0,0,0,0),
 (20,1,'www.grupointellego.com','/ar/','2015-04-17 01:22:25','2016-03-22 19:35:44',1,0,0,0,0,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
