-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:25
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_users
-- Snapshot Table  : 1487614645_users
--
-- SQL    : SELECT * FROM wpn0_users LIMIT 0,10000
-- Offset : 0
-- Rows   : 8
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_users`
--
DROP TABLE  IF EXISTS `1487614645_users`;
CREATE TABLE `1487614645_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_users`
-- Number of rows: 8
--
INSERT INTO `1487614645_users` VALUES 
(1,'saul','$P$BdRcBPeM3eQ0Xkv2mF0kTrdBWOKYF51','saul','saul.diaz.v@gmail.com','','2015-03-17 04:53:18','',0,'saul',0,0),
 (2,'griselda','$P$BbzT4mf5/6Ml1QDvnq.044lyoWbgDv1','griselda','amicigris@gmail.com','','2015-03-18 04:51:18','',0,'griselda',0,0),
 (3,'anita','$P$BrQDpT8NJs8TaTtHNFdQSO7WnobvyB.','anita','anita.barbosa@gmail.com','','2015-04-14 22:20:36','',0,'anita',0,0),
 (4,'rafa','$P$BFhkksOf2Rd.wT9OOFDMEhge1uJU8V0','rafa','rtorrijos@intellego.com.mx','','2015-05-12 15:09:16','',0,'rafa',0,0),
 (5,'david','$P$BcZzgy4zxS4rUDYw.obqNSWlvdVYHo0','david','otorralba@intellego.com.mx','','2015-05-12 15:09:46','',0,'David',0,0),
 (6,'dani','$P$BHfLo3wLPUsYtBKLaAxxhLK5gEC.kj/','dani','dcuenca@intellego.com.mx','','2015-05-12 15:10:00','$P$BRpvyhe6eWCW4my9dJfoHfqvdEYc6B/',0,'Dani',0,0),
 (7,'juanjose','$P$B46FPi9FqpCH7DjAyCBhcyYkYCrz/p/','juanjose','jaceves@intellego.com.mx','','2015-05-12 15:10:23','',0,'Juan José',0,0),
 (8,'jenny','$P$B5t.rPTJEFDgpB9Lyji6IZKVAXy6Ey/','jenny','jvega@intellego.com.mx','','2015-05-12 18:02:58','',0,'jenny',0,0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
