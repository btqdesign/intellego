-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:24
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_registration_log
-- Snapshot Table  : 1487614645_registration_log
--
-- SQL    : SELECT * FROM wpn0_registration_log LIMIT 0,10000
-- Offset : 0
-- Rows   : 20
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_registration_log`
--
DROP TABLE  IF EXISTS `1487614645_registration_log`;
CREATE TABLE `1487614645_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `IP` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_registration_log`
-- Number of rows: 20
--
INSERT INTO `1487614645_registration_log` VALUES 
(1,'saul.diaz.v@gmail.com','127.0.0.1',2,'2015-03-17 20:24:52'),
 (2,'saul.diaz.v@gmail.com','127.0.0.1',3,'2015-03-17 20:25:29'),
 (3,'saul.diaz.v@gmail.com','127.0.0.1',4,'2015-03-17 20:26:12'),
 (4,'saul.diaz.v@gmail.com','127.0.0.1',5,'2015-03-17 20:27:14'),
 (5,'saul.diaz.v@gmail.com','127.0.0.1',6,'2015-03-17 20:27:39'),
 (6,'saul.diaz.v@gmail.com','127.0.0.1',7,'2015-03-17 20:28:13'),
 (7,'amicigris@gmail.com','201.141.141.41',8,'2015-04-15 10:04:42'),
 (8,'amicigris@gmail.com','201.141.141.41',9,'2015-04-15 10:06:53'),
 (9,'saul.diaz.v@gmail.com','189.208.88.144',10,'2015-04-16 18:16:15'),
 (10,'saul.diaz.v@gmail.com','189.208.88.144',11,'2015-04-16 18:19:02'),
 (11,'saul.diaz.v@gmail.com','189.249.63.231',12,'2015-04-16 20:14:16'),
 (12,'saul.diaz.v@gmail.com','189.249.9.117',13,'2015-04-17 01:15:23'),
 (13,'saul.diaz.v@gmail.com','189.249.9.117',14,'2015-04-17 01:16:21'),
 (14,'saul.diaz.v@gmail.com','189.249.9.117',15,'2015-04-17 01:17:11'),
 (15,'saul.diaz.v@gmail.com','189.249.9.117',16,'2015-04-17 01:18:37'),
 (16,'saul.diaz.v@gmail.com','189.249.9.117',17,'2015-04-17 01:19:19'),
 (17,'saul.diaz.v@gmail.com','189.249.9.117',18,'2015-04-17 01:20:13'),
 (18,'saul.diaz.v@gmail.com','189.249.9.117',19,'2015-04-17 01:21:17'),
 (19,'saul.diaz.v@gmail.com','189.249.9.117',20,'2015-04-17 01:22:26'),
 (20,'saul.diaz.v@gmail.com','189.208.88.144',21,'2015-04-28 11:26:02');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
