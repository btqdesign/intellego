-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:26
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_20_icl_translation_status
-- Snapshot Table  : 1487614645_20_icl_translation_status
--
-- SQL    : SELECT * FROM wpn0_20_icl_translation_status LIMIT 0,10000
-- Offset : 0
-- Rows   : 3
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_20_icl_translation_status`
--
DROP TABLE  IF EXISTS `1487614645_20_icl_translation_status`;
CREATE TABLE `1487614645_20_icl_translation_status` (
  `rid` bigint(20) NOT NULL AUTO_INCREMENT,
  `translation_id` bigint(20) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `translator_id` bigint(20) NOT NULL,
  `needs_update` tinyint(4) NOT NULL,
  `md5` varchar(32) NOT NULL,
  `translation_service` varchar(16) NOT NULL,
  `translation_package` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `links_fixed` tinyint(4) NOT NULL DEFAULT '0',
  `_prevstate` longtext,
  PRIMARY KEY (`rid`),
  UNIQUE KEY `translation_id` (`translation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_20_icl_translation_status`
-- Number of rows: 3
--
INSERT INTO `1487614645_20_icl_translation_status` VALUES 
(1,101,0,0,1,'a6a7bcb19b4cd58012a7b25a120fac25','','a:2:{s:3:\"url\";s:34:\"http://www.grupointellego.com/ar?p=1\";s:8:\"contents\";a:5:{s:5:\"title\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:20:\"wqFIb2xhIG11bmRvIQ==\";s:6:\"format\";s:6:\"base64\";}s:4:\"body\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:132:\"QmllbnZlbmlkbyBhIFdvcmRQcmVzcy4gRXN0YSBlcyB0dSBwcmltZXJhIGVudHJhZGEuIEVkw610YWxhIG8gYsOzcnJhbGEsIMKheSBjb21pZW56YSBhIHB1YmxpY2FyIS4=\";s:6:\"format\";s:6:\"base64\";}s:11:\"original_id\";a:2:{s:9:\"translate\";i:0;s:4:\"data\";i:1;}s:10:\"categories\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:22:\"\"U2luIGNhdGVnb3LDrWE=\"\";s:6:\"format\";s:10:\"csv_base64\";}s:12:\"category_ids\";a:2:{s:9:\"translate\";i:0;s:4:\"data\";s:1:\"1\";}}}','2015-03-23 16:43:18',0,NULL),
 (2,196,10,5,0,'8f2d4de69834f539d9b4b0579aa52eb1','local','a:2:{s:3:\"url\";s:30:\"http://www.grupointellego.com/ar?p=3805\";s:8:\"contents\";a:3:{s:5:\"title\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:24:\"TnVlc3Ryb3MgVmFsb3Jlcw==\";s:6:\"format\";s:6:\"base64\";}s:4:\"body\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:0:\"\";s:6:\"format\";s:6:\"base64\";}s:11:\"original_id\";a:2:{s:9:\"translate\";i:0;s:4:\"data\";i:3805;}}}','2015-05-22 12:03:31',0,NULL),
 (3,201,10,3,0,'70407958f19f59ef009e0f9235e55268','local','a:2:{s:3:\"url\";s:45:\"http://www.grupointellego.com/ar?page_id=3463\";s:8:\"contents\";a:3:{s:5:\"title\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:8:\"SG9tZQ==\";s:6:\"format\";s:6:\"base64\";}s:4:\"body\";a:3:{s:9:\"translate\";i:1;s:4:\"data\";s:1168:\"W2NzX2hlYWRpbmcgY29sdW1uX3NpemU9IjEvMSIgY3NfaGVhZGluZ190aXRsZT0iTk9USUNJQVMiIGNzX2hlYWRpbmdfc3R5bGU9IjMiIGNzX2hlYWRpbmdfYWxpZ249ImNlbnRlciIgY3NfaGVhZGluZ19kaXZpZGVyPSJvbiIgPSJudWxsIiBjc19oZWFkaW5nX2RpdmlkZXJfaWNvbj0iaWNvbi1mb2xkZXIyIiBjc19oZWFkaW5nX2ZvbnRfc3R5bGU9Im5vcm1hbCIgY3NfaGVhZGluZ19jb2xvcj0iIzAwMDAwMCJdWy9jc19oZWFkaW5nXQ0KDQpbY3NfYmxvZyBjb2x1bW5fc2l6ZT0iMS8zIiBjc19ibG9nX3NlY3Rpb25fdGl0bGU9IiIgY3NfYmxvZ19jYXQ9Im5vdGljaWFzIiBjc19ibG9nX3ZpZXc9ImJsb2ctY3JvdXNlbCIgY3NfYmxvZ19vcmRlcmJ5PSJBU0MiIGNzX2Jsb2dfZGVzY3JpcHRpb249InllcyLCoCBjc190ZXh0X2FsaWduPSJsZWZ0IiBjc19ibG9nX2V4Y2VycHQ9IjI1NSIgY3NfYmxvZ19udW1fcG9zdD0iMTAiIGJsb2dfcGFnaW5hdGlvbj0iU2hvdyBQYWdpbmF0aW9uIiBjc19ibG9nX2FuaW1hdGlvbj0ic2xpZGVMZWZ0Il0NCg0KW2NzX2J1dHRvbiBjc19idXR0b25fc2l6ZT0iYnRuLXhsZyIgY3NfYnV0dG9uX3RpdGxlPSJWRVIgVE9EQVMgTEFTIE5PVElDSUFTIiBjc19idXR0b25fbGluaz0iaHR0cDovL3d3dy5ncnVwb2ludGVsbGVnby5jb20vYXIvbm90aWNpYXMvIiBjc19idXR0b25fYm9yZGVyPSJubyIgY3NfYnV0dG9uX2JnX2NvbG9yPSIjZmY0MDAwIiBjc19idXR0b25fY29sb3I9IiNmZmZmZmYiID0ibnVsbCIgY3NfYnV0dG9uX2ljb249Imljb24tbmV3c3BhcGVyIiBjc19idXR0b25faWNvbl9wb3NpdGlvbj0icmlnaHQiIGNzX2J1dHRvbl90eXBlPSJyZWN0YW5nbGUiIGNzX2J1dHRvbl90YXJnZXQ9Il9zZWxmIl0=\";s:6:\"format\";s:6:\"base64\";}s:11:\"original_id\";a:2:{s:9:\"translate\";i:0;s:4:\"data\";i:3463;}}}','2015-05-22 14:59:56',0,NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
