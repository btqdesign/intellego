-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:24
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_blog_versions
-- Snapshot Table  : 1487614645_blog_versions
--
-- SQL    : SELECT * FROM wpn0_blog_versions LIMIT 0,10000
-- Offset : 0
-- Rows   : 10
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_blog_versions`
--
DROP TABLE  IF EXISTS `1487614645_blog_versions`;
CREATE TABLE `1487614645_blog_versions` (
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `db_version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_updated` datetime NOT NULL DEFAULT '1970-01-02 00:00:01',
  PRIMARY KEY (`blog_id`),
  KEY `db_version` (`db_version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_blog_versions`
-- Number of rows: 10
--
INSERT INTO `1487614645_blog_versions` VALUES 
(1,'37965','2015-04-24 11:33:51'),
 (12,'37965','2015-04-24 11:38:36'),
 (13,'37965','2015-04-24 11:38:36'),
 (14,'37965','2015-04-24 11:38:35'),
 (15,'37965','2015-04-24 11:38:33'),
 (16,'37965','2015-04-24 11:38:30'),
 (17,'37965','2015-04-24 11:38:29'),
 (18,'37965','2015-04-24 11:38:28'),
 (19,'37965','2015-04-24 11:38:27'),
 (20,'37965','2015-04-24 11:38:25');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
