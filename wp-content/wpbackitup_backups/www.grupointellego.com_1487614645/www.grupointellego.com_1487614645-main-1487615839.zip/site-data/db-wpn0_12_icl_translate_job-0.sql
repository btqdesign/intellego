-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:21
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_12_icl_translate_job
-- Snapshot Table  : 1487614645_12_icl_translate_job
--
-- SQL    : SELECT * FROM wpn0_12_icl_translate_job LIMIT 0,10000
-- Offset : 0
-- Rows   : 119
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_12_icl_translate_job`
--
DROP TABLE  IF EXISTS `1487614645_12_icl_translate_job`;
CREATE TABLE `1487614645_12_icl_translate_job` (
  `job_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rid` bigint(20) unsigned NOT NULL,
  `translator_id` int(10) unsigned NOT NULL,
  `translated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `manager_id` int(10) unsigned NOT NULL,
  `revision` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`job_id`),
  KEY `rid` (`rid`,`translator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_12_icl_translate_job`
-- Number of rows: 119
--
INSERT INTO `1487614645_12_icl_translate_job` VALUES 
(1,1,0,0,1,NULL),
 (2,2,5,1,5,1),
 (3,2,5,1,5,2),
 (4,3,5,1,5,1),
 (5,4,5,1,5,1),
 (6,4,5,1,3,NULL),
 (7,3,5,1,5,2),
 (8,3,5,1,5,3),
 (9,3,5,1,5,4),
 (10,3,5,1,5,NULL),
 (11,5,5,1,5,NULL),
 (12,6,5,1,5,NULL),
 (13,7,5,1,5,NULL),
 (14,8,5,1,5,NULL),
 (15,9,5,1,5,1),
 (16,10,5,1,5,NULL),
 (17,11,5,1,5,NULL),
 (18,12,5,1,5,NULL),
 (19,9,5,1,5,NULL),
 (20,2,5,1,5,3),
 (21,13,5,1,5,1),
 (22,13,5,1,5,2),
 (23,2,5,1,5,4),
 (24,14,5,1,5,1),
 (25,15,5,1,5,1),
 (26,15,5,1,5,2),
 (27,16,5,1,5,1),
 (28,16,5,1,5,2),
 (29,13,3,1,3,3),
 (30,13,5,1,5,4),
 (31,14,4,1,5,2),
 (32,14,5,1,5,3),
 (33,15,5,1,5,3),
 (34,16,5,1,5,3),
 (35,14,5,1,5,4),
 (36,2,5,1,5,NULL),
 (37,15,5,1,5,NULL),
 (38,13,5,1,3,5),
 (39,17,5,1,5,NULL),
 (40,18,5,1,5,NULL),
 (41,14,6,1,5,5),
 (42,19,5,1,5,NULL),
 (43,20,5,1,5,NULL),
 (44,21,5,1,5,NULL),
 (45,22,5,1,5,NULL),
 (46,23,5,1,5,NULL),
 (47,24,5,1,5,NULL),
 (48,25,5,1,5,NULL),
 (49,26,5,1,5,NULL),
 (50,27,5,1,5,NULL),
 (51,28,5,1,5,1),
 (52,28,5,1,5,NULL),
 (53,29,5,1,5,NULL),
 (54,30,5,1,5,NULL),
 (55,13,5,1,5,NULL),
 (56,31,5,1,5,1),
 (57,32,5,1,5,NULL),
 (58,33,5,1,5,NULL),
 (59,34,5,1,5,NULL),
 (60,35,5,1,5,NULL),
 (61,36,5,1,5,NULL),
 (62,37,5,1,5,NULL),
 (63,38,5,1,5,NULL),
 (64,39,5,1,5,NULL),
 (65,40,5,1,5,NULL),
 (66,41,5,1,5,NULL),
 (67,42,5,1,5,1),
 (68,43,5,1,5,NULL),
 (69,44,5,1,5,NULL),
 (70,45,5,1,5,1),
 (71,45,5,1,5,NULL),
 (72,14,5,1,5,NULL),
 (73,46,5,1,5,1),
 (74,46,5,1,5,2),
 (75,46,5,1,5,3),
 (76,46,5,1,5,NULL),
 (77,47,5,1,5,NULL),
 (78,48,5,1,5,1),
 (79,48,5,1,5,NULL),
 (80,31,5,0,5,NULL),
 (81,42,5,1,5,NULL),
 (82,49,5,1,5,NULL),
 (83,50,5,1,5,NULL),
 (84,51,5,1,5,NULL),
 (85,52,5,1,5,NULL),
 (86,53,5,1,5,NULL),
 (87,54,5,1,5,NULL),
 (88,55,5,1,5,1),
 (89,56,5,1,5,NULL),
 (90,57,5,1,5,NULL),
 (91,58,5,1,5,1),
 (92,58,5,1,5,2),
 (93,58,5,1,5,NULL),
 (94,59,5,1,5,NULL),
 (95,60,5,1,5,NULL),
 (96,61,5,1,5,1),
 (97,61,5,1,5,NULL),
 (98,62,5,1,5,NULL),
 (99,63,5,1,5,1),
 (100,63,5,1,5,NULL),
 (101,64,5,1,5,1),
 (102,65,5,1,5,1),
 (103,66,5,1,5,1),
 (104,67,5,1,5,1),
 (105,68,5,1,5,NULL),
 (106,69,5,1,5,NULL),
 (107,65,5,1,5,NULL),
 (108,66,5,1,5,2),
 (109,67,5,1,5,2),
 (110,67,5,1,5,NULL),
 (111,64,5,1,5,NULL),
 (112,66,5,1,5,NULL),
 (113,55,5,1,5,NULL),
 (114,70,5,1,5,NULL),
 (115,71,5,1,5,NULL),
 (116,72,5,1,5,NULL),
 (117,73,5,1,5,NULL),
 (118,74,5,1,5,NULL),
 (119,16,5,1,5,NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
