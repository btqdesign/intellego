-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:22
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_19_icl_translate_job
-- Snapshot Table  : 1487614645_19_icl_translate_job
--
-- SQL    : SELECT * FROM wpn0_19_icl_translate_job LIMIT 0,10000
-- Offset : 0
-- Rows   : 67
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_19_icl_translate_job`
--
DROP TABLE  IF EXISTS `1487614645_19_icl_translate_job`;
CREATE TABLE `1487614645_19_icl_translate_job` (
  `job_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rid` bigint(20) unsigned NOT NULL,
  `translator_id` int(10) unsigned NOT NULL,
  `translated` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `manager_id` int(10) unsigned NOT NULL,
  `revision` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`job_id`),
  KEY `rid` (`rid`,`translator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_19_icl_translate_job`
-- Number of rows: 67
--
INSERT INTO `1487614645_19_icl_translate_job` VALUES 
(1,1,0,0,1,NULL),
 (2,2,5,1,5,NULL),
 (3,3,5,1,5,NULL),
 (4,4,5,1,5,1),
 (5,4,5,1,5,NULL),
 (6,5,5,1,5,1),
 (7,5,5,1,5,NULL),
 (8,6,5,1,5,1),
 (9,6,5,1,5,NULL),
 (10,7,5,1,5,1),
 (11,7,5,1,5,NULL),
 (12,8,5,1,5,1),
 (13,8,5,1,5,2),
 (14,8,5,1,5,3),
 (15,8,5,1,3,4),
 (16,8,3,1,5,5),
 (17,8,5,1,3,6),
 (18,8,5,1,5,NULL),
 (19,9,5,1,5,NULL),
 (20,10,5,1,5,NULL),
 (21,11,5,1,5,NULL),
 (22,12,5,1,5,NULL),
 (23,13,5,1,5,NULL),
 (24,14,5,1,5,1),
 (25,14,5,1,5,NULL),
 (26,15,5,1,5,NULL),
 (27,16,5,1,5,NULL),
 (28,17,5,1,5,1),
 (29,17,5,1,5,NULL),
 (30,18,5,1,5,NULL),
 (31,19,5,1,5,NULL),
 (32,20,5,1,5,NULL),
 (33,21,5,1,5,1),
 (34,22,5,1,5,1),
 (35,23,5,1,5,1),
 (36,24,5,1,5,NULL),
 (37,25,5,1,5,1),
 (38,26,5,1,5,NULL),
 (39,27,5,1,5,NULL),
 (40,28,5,1,5,1),
 (41,28,5,1,5,NULL),
 (42,29,5,1,5,1),
 (43,30,5,1,5,NULL),
 (44,31,5,1,5,NULL),
 (45,32,5,1,5,NULL),
 (46,33,5,1,5,1),
 (47,33,5,1,5,2),
 (48,34,5,1,5,NULL),
 (49,35,5,1,5,NULL),
 (50,36,5,1,5,NULL),
 (51,37,5,1,5,NULL),
 (52,38,5,1,5,NULL),
 (53,39,5,1,5,1),
 (54,40,5,1,5,NULL),
 (55,39,5,0,5,NULL),
 (56,25,5,1,5,NULL),
 (57,41,5,1,5,NULL),
 (58,42,5,1,5,NULL),
 (59,43,5,1,5,NULL),
 (60,44,5,1,5,NULL),
 (61,45,5,1,5,NULL),
 (62,22,5,1,5,NULL),
 (63,23,5,1,5,2),
 (64,23,5,0,5,NULL),
 (65,29,5,0,5,NULL),
 (66,33,5,1,5,NULL),
 (67,21,5,0,5,NULL);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
