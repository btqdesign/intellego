-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:20
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_14_term_taxonomy
-- Snapshot Table  : 1487614645_14_term_taxonomy
--
-- SQL    : SELECT * FROM wpn0_14_term_taxonomy LIMIT 0,10000
-- Offset : 0
-- Rows   : 171
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_14_term_taxonomy`
--
DROP TABLE  IF EXISTS `1487614645_14_term_taxonomy`;
CREATE TABLE `1487614645_14_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_14_term_taxonomy`
-- Number of rows: 171
--
INSERT INTO `1487614645_14_term_taxonomy` VALUES 
(1,1,'category','',0,5),
 (8,8,'nav_menu','',0,50),
 (9,9,'category','',0,0),
 (11,11,'category','',0,0),
 (13,13,'category','',0,0),
 (15,15,'category','',0,0),
 (17,17,'category','',0,0),
 (19,19,'category','',0,0),
 (21,21,'post_tag','',0,0),
 (23,23,'post_tag','',0,0),
 (25,25,'post_tag','',0,0),
 (27,27,'post_tag','',0,0),
 (29,29,'post_tag','',0,0),
 (31,31,'member-category','',0,0),
 (33,33,'member-category','',0,0),
 (35,35,'member-category','',0,0),
 (37,37,'member-category','',0,0),
 (39,39,'nav_menu','',0,0),
 (40,40,'category','',0,14),
 (41,41,'project-category','',0,12),
 (42,42,'project-category','',0,4),
 (43,43,'project-category','',0,5),
 (45,45,'project-category','',0,5),
 (47,47,'nav_menu','',0,4),
 (48,48,'category','',0,3),
 (49,49,'category','',0,0),
 (50,50,'member-category','',0,0),
 (51,51,'project-category','',0,0),
 (52,52,'project-category','',0,0),
 (53,53,'project-tag','',0,0),
 (54,54,'post_tag','',0,2),
 (55,55,'post_tag','',0,6),
 (56,56,'post_tag','',0,1),
 (57,57,'post_tag','',0,2),
 (58,58,'post_tag','',0,1),
 (59,59,'post_tag','',0,2),
 (60,60,'category','',0,0),
 (61,61,'post_tag','',0,0),
 (62,62,'post_tag','',0,1),
 (63,63,'post_tag','',0,1),
 (64,64,'post_tag','',0,1),
 (65,65,'post_tag','',0,2),
 (66,66,'post_tag','',0,1),
 (67,67,'post_tag','',0,4),
 (68,68,'project-tag','',0,9),
 (69,69,'project-tag','',0,1),
 (70,70,'project-tag','',0,2),
 (71,71,'project-tag','',0,2),
 (72,72,'project-tag','',0,10),
 (73,73,'project-tag','',0,2),
 (74,74,'project-tag','',0,3),
 (75,75,'project-tag','',0,7),
 (76,76,'project-tag','',0,1),
 (77,77,'project-tag','',0,4),
 (78,78,'project-tag','',0,1),
 (79,79,'category','',0,0),
 (80,80,'post_tag','',0,3),
 (81,81,'post_tag','',0,10),
 (82,82,'post_tag','',0,2),
 (83,83,'post_tag','',0,3),
 (84,84,'post_tag','',0,2),
 (85,85,'post_tag','',0,3),
 (86,86,'category','',0,0),
 (87,87,'category','',0,0),
 (88,88,'category','',0,0),
 (89,89,'category','',0,0),
 (90,90,'category','',0,0),
 (91,91,'post_tag','',0,1),
 (92,92,'post_tag','',0,1),
 (93,93,'category','',0,0),
 (94,94,'category','',0,0),
 (95,95,'category','',0,1),
 (96,96,'post_tag','',0,1),
 (97,97,'category','',0,0),
 (98,98,'category','',0,0),
 (99,99,'post_tag','',0,2),
 (100,100,'post_tag','',0,6),
 (101,101,'category','',0,0),
 (102,102,'category','',0,0),
 (103,103,'category','',0,0),
 (104,104,'category','',0,3),
 (105,105,'post_tag','',0,2),
 (106,106,'post_tag','',0,1),
 (107,107,'category','',0,4),
 (108,108,'category','',0,4),
 (109,109,'category','',0,6),
 (110,110,'category','',0,2),
 (111,111,'post_tag','',0,4),
 (112,112,'post_tag','',0,2),
 (113,113,'post_tag','',0,1),
 (114,114,'post_tag','',0,1),
 (115,115,'category','',0,1),
 (116,116,'post_tag','',0,1),
 (117,117,'project-tag','',0,6),
 (118,118,'project-tag','',0,2),
 (119,119,'project-tag','',0,2),
 (120,120,'project-tag','',0,2),
 (121,121,'project-tag','',0,0),
 (122,122,'project-tag','',0,0),
 (123,123,'project-tag','',0,1),
 (124,124,'project-tag','',0,2),
 (125,125,'project-tag','',0,1),
 (126,126,'project-tag','',0,1),
 (127,127,'project-tag','',0,1),
 (128,128,'project-tag','',0,1),
 (129,129,'project-tag','',0,1),
 (130,130,'project-tag','',0,1),
 (131,131,'project-tag','',0,1),
 (132,132,'project-tag','',0,2),
 (133,133,'project-tag','',0,4),
 (134,134,'project-tag','',0,1),
 (135,135,'project-tag','',0,4),
 (136,136,'project-tag','',0,1),
 (137,137,'project-tag','',0,1),
 (138,138,'project-tag','',0,1),
 (139,139,'project-tag','',0,3),
 (140,140,'project-tag','',0,1),
 (141,141,'project-category','',0,1),
 (142,142,'project-tag','',0,1),
 (143,143,'project-category','',0,0),
 (144,144,'project-category','',0,9),
 (145,145,'project-category','',0,0),
 (146,146,'project-tag','',0,0),
 (147,147,'project-tag','',0,0),
 (148,148,'project-tag','',0,0),
 (149,149,'project-tag','',0,0),
 (150,150,'project-category','',0,5),
 (151,151,'project-tag','',0,2),
 (152,152,'project-tag','',0,1),
 (153,153,'project-tag','',0,1),
 (154,154,'project-tag','',0,2),
 (155,155,'category','',0,0),
 (156,156,'category','',0,0),
 (157,157,'category','',0,0),
 (158,158,'category','',0,0),
 (159,159,'post_tag','',0,1),
 (160,160,'category','',0,0),
 (161,161,'category','',0,0),
 (162,162,'category','',0,1),
 (163,163,'category','',0,0),
 (164,164,'category','',0,0),
 (165,165,'category','',0,1),
 (166,166,'category','',0,1),
 (167,167,'category','',0,1),
 (168,168,'category','',0,12),
 (169,169,'category','',0,1),
 (170,170,'post_tag','',0,2),
 (171,171,'category','',0,1),
 (172,172,'category','',0,3),
 (173,173,'post_tag','',0,3),
 (174,174,'post_tag','',0,6),
 (175,175,'post_tag','',0,3),
 (176,176,'post_tag','',0,1),
 (177,177,'post_tag','',0,1),
 (178,178,'post_tag','',0,1),
 (179,179,'post_tag','',0,1),
 (180,180,'category','',0,1),
 (181,181,'post_tag','',0,2),
 (182,182,'post_tag','',0,1),
 (183,183,'post_tag','',0,2),
 (184,184,'post_tag','',0,1),
 (185,185,'post_tag','',0,2),
 (186,186,'post_tag','',0,1),
 (187,187,'post_tag','',0,1),
 (188,188,'post_tag','',0,1),
 (189,189,'post_tag','',0,1),
 (190,190,'project-tag','',0,1),
 (191,191,'project-tag','',0,1),
 (192,192,'project-tag','',0,1),
 (193,193,'project-tag','',0,1),
 (194,194,'project-tag','',0,1);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
