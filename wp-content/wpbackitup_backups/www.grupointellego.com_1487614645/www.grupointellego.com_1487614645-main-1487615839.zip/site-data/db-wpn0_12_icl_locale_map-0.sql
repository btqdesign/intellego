-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:26
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_12_icl_locale_map
-- Snapshot Table  : 1487614645_12_icl_locale_map
--
-- SQL    : SELECT * FROM wpn0_12_icl_locale_map LIMIT 0,10000
-- Offset : 0
-- Rows   : 2
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_12_icl_locale_map`
--
DROP TABLE  IF EXISTS `1487614645_12_icl_locale_map`;
CREATE TABLE `1487614645_12_icl_locale_map` (
  `code` varchar(7) NOT NULL,
  `locale` varchar(8) NOT NULL,
  UNIQUE KEY `code` (`code`,`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_12_icl_locale_map`
-- Number of rows: 2
--
INSERT INTO `1487614645_12_icl_locale_map` VALUES 
('en','en_US'),
 ('es','es_ES');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
