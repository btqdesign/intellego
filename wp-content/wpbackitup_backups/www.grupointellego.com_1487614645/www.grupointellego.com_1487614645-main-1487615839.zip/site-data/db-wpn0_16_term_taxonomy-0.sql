-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:21
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_16_term_taxonomy
-- Snapshot Table  : 1487614645_16_term_taxonomy
--
-- SQL    : SELECT * FROM wpn0_16_term_taxonomy LIMIT 0,10000
-- Offset : 0
-- Rows   : 109
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_16_term_taxonomy`
--
DROP TABLE  IF EXISTS `1487614645_16_term_taxonomy`;
CREATE TABLE `1487614645_16_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_16_term_taxonomy`
-- Number of rows: 109
--
INSERT INTO `1487614645_16_term_taxonomy` VALUES 
(1,1,'category','',0,5),
 (8,8,'nav_menu','',0,50),
 (9,9,'category','',0,0),
 (11,11,'category','',0,0),
 (13,13,'category','',0,0),
 (15,15,'category','',0,0),
 (17,17,'category','',0,0),
 (19,19,'category','',0,0),
 (21,21,'post_tag','',0,0),
 (23,23,'post_tag','',0,0),
 (25,25,'post_tag','',0,0),
 (27,27,'post_tag','',0,0),
 (29,29,'post_tag','',0,0),
 (31,31,'member-category','',0,0),
 (33,33,'member-category','',0,0),
 (35,35,'member-category','',0,0),
 (37,37,'member-category','',0,0),
 (39,39,'nav_menu','',0,0),
 (40,40,'category','',0,10),
 (41,41,'project-category','',0,13),
 (42,42,'project-category','',0,1),
 (43,43,'project-category','',0,1),
 (45,45,'project-category','',0,1),
 (47,47,'nav_menu','',0,4),
 (48,48,'category','',0,3),
 (49,49,'category','',0,0),
 (50,50,'member-category','',0,3),
 (51,51,'project-category','',0,0),
 (52,52,'project-category','',0,0),
 (53,53,'project-tag','',0,0),
 (54,54,'post_tag','',0,2),
 (55,55,'post_tag','',0,6),
 (56,56,'post_tag','',0,1),
 (57,57,'post_tag','',0,2),
 (58,58,'post_tag','',0,1),
 (59,59,'post_tag','',0,2),
 (60,60,'category','',0,0),
 (61,61,'post_tag','',0,0),
 (62,62,'post_tag','',0,1),
 (63,63,'post_tag','',0,1),
 (64,64,'post_tag','',0,1),
 (65,65,'post_tag','',0,2),
 (66,66,'post_tag','',0,1),
 (67,67,'post_tag','',0,4),
 (68,68,'project-tag','',0,4),
 (69,69,'project-tag','',0,1),
 (70,70,'project-tag','',0,1),
 (71,71,'project-tag','',0,1),
 (72,72,'project-tag','',0,7),
 (73,73,'project-tag','',0,2),
 (74,74,'project-tag','',0,3),
 (75,75,'project-tag','',0,3),
 (76,76,'project-tag','',0,1),
 (77,77,'project-tag','',0,2),
 (78,78,'project-tag','',0,1),
 (79,79,'category','',0,0),
 (80,80,'post_tag','',0,1),
 (81,81,'post_tag','',0,4),
 (82,82,'post_tag','',0,1),
 (83,83,'post_tag','',0,1),
 (84,84,'post_tag','',0,1),
 (85,85,'post_tag','',0,1),
 (86,86,'category','',0,0),
 (87,87,'category','',0,0),
 (88,88,'category','',0,0),
 (89,89,'category','',0,0),
 (90,90,'category','',0,0),
 (91,91,'post_tag','',0,1),
 (92,92,'post_tag','',0,1),
 (93,93,'category','',0,0),
 (94,94,'category','',0,0),
 (95,95,'category','',0,0),
 (96,96,'post_tag','',0,1),
 (97,97,'category','',0,0),
 (98,98,'category','',0,0),
 (99,99,'post_tag','',0,1),
 (100,100,'post_tag','',0,3),
 (101,101,'category','',0,0),
 (102,102,'category','',0,0),
 (103,103,'category','',0,0),
 (104,104,'category','',0,3),
 (105,105,'post_tag','',0,1),
 (106,106,'post_tag','',0,1),
 (107,107,'category','',0,4),
 (108,108,'category','',0,3),
 (109,109,'category','',0,0),
 (110,110,'category','',0,0),
 (111,111,'post_tag','',0,1),
 (112,112,'post_tag','',0,1),
 (113,113,'post_tag','',0,1),
 (114,114,'post_tag','',0,1),
 (115,115,'category','',0,1),
 (116,116,'post_tag','',0,1),
 (117,117,'project-tag','',0,3),
 (118,118,'project-tag','',0,1),
 (119,119,'project-tag','',0,2),
 (120,120,'project-tag','',0,2),
 (121,121,'project-tag','',0,1),
 (122,122,'project-tag','',0,1),
 (123,123,'project-tag','',0,1),
 (124,124,'project-tag','',0,1),
 (125,125,'project-tag','',0,1),
 (126,126,'project-tag','',0,1),
 (127,127,'project-tag','',0,1),
 (128,128,'project-tag','',0,1),
 (129,129,'project-tag','',0,1),
 (130,130,'project-tag','',0,1),
 (131,131,'project-category','',0,0),
 (132,132,'post_tag','',0,1);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
