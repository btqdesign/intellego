-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:20
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_14_terms
-- Snapshot Table  : 1487614645_14_terms
--
-- SQL    : SELECT * FROM wpn0_14_terms LIMIT 0,10000
-- Offset : 0
-- Rows   : 171
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_14_terms`
--
DROP TABLE  IF EXISTS `1487614645_14_terms`;
CREATE TABLE `1487614645_14_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_14_terms`
-- Number of rows: 171
--
INSERT INTO `1487614645_14_terms` VALUES 
(1,'Sin categoría','sin-categoria',0),
 (8,'Main Menu','main-menu',0),
 (9,'Blogs','blogs',0),
 (11,'Construction','construction',0),
 (13,'Design Build','design-build',0),
 (15,'Development','development',0),
 (17,'Houses','houses',0),
 (19,'Projects','projects',0),
 (21,'Blogs','blogs',0),
 (23,'Construction','construction',0),
 (25,'Design Build','design-build',0),
 (27,'Development','development',0),
 (29,'Houses','houses',0),
 (31,'Beginner','beginner',0),
 (33,'Builders','builders',0),
 (35,'Construction','construction',0),
 (37,'Designing','designing',0),
 (39,'Widget Menu','widget-menu',0),
 (40,'Noticias','noticias',0),
 (41,'Artículos','articulos',0),
 (42,'Brochures','brochures',0),
 (43,'Casos de éxito','casos-de-exito',0),
 (45,'Videos','videos',0),
 (47,'Footer Menu','footer-menu',0),
 (48,'Vacantes','vacantes',0),
 (49,'Sin categoría @en','sin-categoria-en',0),
 (50,'equipo mexico','equipo-mexico',0),
 (51,'SAP','sap',0),
 (52,'Categoria de prueba','categoria-de-prueba',0),
 (53,'Prueba','prueba',0),
 (54,'Expansión','expansion',0),
 (55,'Felipe Labbé','felipe-labbe',0),
 (56,'Intellego','intellego',0),
 (57,'Logros','logros',0),
 (58,'Multilatinas','multilatinas',0),
 (59,'Reconocimientos','reconocimientos',0),
 (60,'Noticias','noticias-en',0),
 (61,'Eduardo Graniello','eduardo-graniello-2',0),
 (62,'Eventos','eventos',0),
 (63,'Partner','partner',0),
 (64,'SAP','sap',0),
 (65,'Business Intelligence','business-intelligence',0),
 (66,'Medios','medios',0),
 (67,'Tecnología de la Información','tecnologia-de-la-informacion',0),
 (68,'Business Intelligence','business-intelligence',0),
 (69,'Information Management Strategy','information-management-strategy',0),
 (70,'Data Warehouse','data-warehouse',0),
 (71,'ETL','etl',0),
 (72,'Information Management','information-management',0),
 (73,'Data Management','data-management',0),
 (74,'Tecnologías de la Información','tecnologias-de-la-informacion',0),
 (75,'advanced analytics','advanced-analytics',0),
 (76,'Customer Relationship Management','customer-relationship-management',0),
 (77,'Optimizar Procesos','optimizar-procesos',0),
 (78,'ROI','roi',0),
 (79,'Noticias','noticias-en-2',0),
 (80,'Expansión','expansion-en',0),
 (81,'Felipe Labbé','felipe-labbe-en',0),
 (82,'Intellego','intellego-en',0),
 (83,'Logros','logros-en',0),
 (84,'Multilatinas','multilatinas-en',0),
 (85,'Reconocimientos','reconocimientos-en',0),
 (86,'Noticias','noticias-en-3',0),
 (87,'Noticias','noticias-en-4',0),
 (88,'Noticias','noticias-en-5',0),
 (89,'Noticias','noticias-en-6',0),
 (90,'Noticias','noticias-en-7',0),
 (91,'Acknowledgments','acknowledgments',0),
 (92,'Awards','awards',0),
 (93,'Noticias','noticias-en-8',0),
 (94,'Noticias','noticias-en-9',0),
 (95,'Notas de Prensa','notas-de-prensa-en',0),
 (96,'Notas de Prensa','notas-de-prensa',0),
 (97,'Notas de Prensa','notas-de-prensa-en-2',0),
 (98,'Noticias','noticias-en-10',0),
 (99,'Notas de Prensa','notas-de-prensa-en',0),
 (100,'Tecnología de la Información','tecnologia-de-la-informacion-en',0),
 (101,'Noticias','noticias-en-11',0),
 (102,'Noticias','noticias-en-12',0),
 (103,'Noticias','noticias-en-13',0),
 (104,'Notas de Prensa','notas-de-prensa',0),
 (105,'Business Service Management','business-service-management',0),
 (106,'Extension','extension',0),
 (107,'News','news-en',0),
 (108,'Press','press',0),
 (109,'News','news-en-2',0),
 (110,'Press','press-2',0),
 (111,'Business Service Management','business-service-management-en',0),
 (112,'Extension','extension-en',0),
 (113,'BMC','bmc',0),
 (114,'Monitoreo','monitoreo',0),
 (115,'Artículo','articulo',0),
 (116,'BIG DATA','big-data',0),
 (117,'Big Data','big-data',0),
 (118,'App','app',0),
 (119,'App Development','app-development',0),
 (120,'Desarrollo de Software','desarrollo-de-software',0),
 (121,'Aplicaciones','aplicaciones',0),
 (122,'Apps','apps',0),
 (123,'Economía','economia',0),
 (124,'Enterprise Performance Management','enterprise-performance-management',0),
 (125,'Regulaciones Fiscales','regulaciones-fiscales',0),
 (126,'Seguros','seguros',0),
 (127,'Big Data Analytics','big-data-analytics',0),
 (128,'Geoanalitica','geoanalitica',0),
 (129,'Gobierno Digital','gobierno-digital',0),
 (130,'Gobierno Sin Papel','gobierno-sin-papel',0),
 (131,'SAP','sap',0),
 (132,'TIME','time',0),
 (133,'Casos de Éxito','casos-de-exito',0),
 (134,'Cloud','cloud',0),
 (135,'Success Stories','success-stories',0),
 (136,'Business Solutions','business-solutions',0),
 (137,'Planeación financiera','planeacion-financiera',0),
 (138,'Intellego','intellego',0),
 (139,'videos','videos',0),
 (140,'Brochures','brochures',0),
 (141,'Infografías','infografias',0),
 (142,'brochure','brochure',0),
 (143,'Artículos 2','articulos-2',0),
 (144,'Articles','articles',0),
 (145,'Artículos','articulos-en',0),
 (146,'Data Management','data-management-en',0),
 (147,'Gobierno Digital','gobierno-digital-en',0),
 (148,'Gobierno Sin Papel','gobierno-sin-papel-en',0),
 (149,'Information Management','information-management-en',0),
 (150,'Artículos','articulos-en-2',0),
 (151,'Business Intelligence','business-intelligence-en',0),
 (152,'Data Warehouse','data-warehouse-en',0),
 (153,'ETL','etl-en',0),
 (154,'Information Management','information-management-en-2',0),
 (155,'Notas de Prensa','notas-de-prensa-en-en',0),
 (156,'Noticias','noticias-en-14',0),
 (157,'Notas de Prensa','notas-de-prensa-en-en-2',0),
 (158,'Noticias','noticias-en-14-2',0),
 (159,'Business Service Management','business-service-management-en-2',0),
 (160,'Notas de Prensa','notas-de-prensa-en-en-3',0),
 (161,'Noticias','noticias-en-14-3',0),
 (162,'Press','press-en',0),
 (163,'Notas de Prensa','notas-de-prensa-en-en-4',0),
 (164,'Noticias','noticias-en-14-4',0),
 (165,'Notas de Prensa','notas-de-prensa-en-en-5',0),
 (166,'Noticias','noticias-en-14-5',0),
 (167,'Notas de Prensa','notas-de-prensa-en-en-6',0),
 (168,'Noticias','noticias-en-15',0),
 (169,'Press','press-en-2',0),
 (170,'Business Service Management','business-service-management-en-3',0),
 (171,'News','news-en-en',0),
 (172,'Notas de Prensa','notas-de-prensa-en-3',0),
 (173,'Business Intelligence','business-intelligence-en',0),
 (174,'Felipe Labbé','felipe-labbe-en-2',0),
 (175,'Tecnología de la Información','tecnologia-de-la-informacion-en-2',0),
 (176,'BMC','bmc-en',0),
 (177,'Extension','extension-en-2',0),
 (178,'Monitoreo','monitoreo-en',0),
 (179,'Notas de Prensa','notas-de-prensa-en-2',0),
 (180,'Sin categoría','sin-categoria-en-2',0),
 (181,'Expansión','expansion-en-2',0),
 (182,'Intellego','intellego-en-2',0),
 (183,'Logros','logros-en-2',0),
 (184,'Multilatinas','multilatinas-en-2',0),
 (185,'Reconocimientos','reconocimientos-en-2',0),
 (186,'Eventos','eventos-en',0),
 (187,'Partner','partner-en',0),
 (188,'SAP','sap-en',0),
 (189,'Medios','medios-en',0),
 (190,'App','app-en',0),
 (191,'App Development','app-development-en',0),
 (192,'Desarrollo de Software','desarrollo-de-software-en',0),
 (193,'advanced analytics','advanced-analytics-en',0),
 (194,'Big Data','big-data-en',0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
