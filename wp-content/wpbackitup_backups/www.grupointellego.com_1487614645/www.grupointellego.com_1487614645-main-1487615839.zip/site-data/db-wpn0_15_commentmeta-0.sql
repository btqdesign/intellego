-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:23
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_15_commentmeta
-- Snapshot Table  : 1487614645_15_commentmeta
--
-- SQL    : SELECT * FROM wpn0_15_commentmeta LIMIT 0,10000
-- Offset : 0
-- Rows   : 174
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_15_commentmeta`
--
DROP TABLE  IF EXISTS `1487614645_15_commentmeta`;
CREATE TABLE `1487614645_15_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_15_commentmeta`
-- Number of rows: 174
--
INSERT INTO `1487614645_15_commentmeta` VALUES 
(1,1,'akismet_error','1468363274'),
 (2,1,'akismet_history','a:3:{s:4:\"time\";d:1468363274.816833;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (4,1,'akismet_delayed_moderation_email','1'),
 (5,2,'akismet_error','1471368935'),
 (6,2,'akismet_history','a:3:{s:4:\"time\";d:1471368935.373523;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (8,2,'akismet_delayed_moderation_email','1'),
 (9,3,'akismet_error','1472018182'),
 (10,3,'akismet_history','a:3:{s:4:\"time\";d:1472018182.6743791;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (12,3,'akismet_delayed_moderation_email','1'),
 (13,4,'akismet_error','1472563010'),
 (14,4,'akismet_history','a:3:{s:4:\"time\";d:1472563010.0764551;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (16,4,'akismet_delayed_moderation_email','1'),
 (17,5,'akismet_error','1472986551'),
 (18,5,'akismet_history','a:3:{s:4:\"time\";d:1472986551.8721521;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (20,5,'akismet_delayed_moderation_email','1'),
 (21,6,'akismet_error','1472986579'),
 (22,6,'akismet_history','a:3:{s:4:\"time\";d:1472986579.8487389;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (24,6,'akismet_delayed_moderation_email','1'),
 (25,7,'akismet_error','1473039084'),
 (26,7,'akismet_history','a:3:{s:4:\"time\";d:1473039084.4426849;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (28,7,'akismet_delayed_moderation_email','1'),
 (29,8,'akismet_error','1473107798'),
 (30,8,'akismet_history','a:3:{s:4:\"time\";d:1473107798.4256811;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (32,8,'akismet_delayed_moderation_email','1'),
 (33,9,'akismet_error','1473165200'),
 (34,9,'akismet_history','a:3:{s:4:\"time\";d:1473165200.4572921;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (36,9,'akismet_delayed_moderation_email','1'),
 (37,10,'akismet_error','1473179554'),
 (38,10,'akismet_history','a:3:{s:4:\"time\";d:1473179554.6189671;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (40,10,'akismet_delayed_moderation_email','1'),
 (41,11,'akismet_error','1473693184'),
 (42,11,'akismet_history','a:3:{s:4:\"time\";d:1473693184.086375;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (44,11,'akismet_delayed_moderation_email','1'),
 (45,12,'akismet_error','1473693211'),
 (46,12,'akismet_history','a:3:{s:4:\"time\";d:1473693211.88258;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (48,12,'akismet_delayed_moderation_email','1'),
 (49,13,'akismet_error','1474149910'),
 (50,13,'akismet_history','a:3:{s:4:\"time\";d:1474149910.598866;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (52,13,'akismet_delayed_moderation_email','1'),
 (53,14,'akismet_error','1474149966'),
 (54,14,'akismet_history','a:3:{s:4:\"time\";d:1474149966.581248;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (56,14,'akismet_delayed_moderation_email','1'),
 (57,15,'akismet_error','1474363361'),
 (58,15,'akismet_history','a:3:{s:4:\"time\";d:1474363361.4854259;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (60,15,'akismet_delayed_moderation_email','1'),
 (61,16,'akismet_error','1474640137'),
 (62,16,'akismet_history','a:3:{s:4:\"time\";d:1474640137.392045;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (64,16,'akismet_delayed_moderation_email','1'),
 (65,17,'akismet_error','1474640201'),
 (66,17,'akismet_history','a:3:{s:4:\"time\";d:1474640201.987051;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (68,17,'akismet_delayed_moderation_email','1'),
 (69,18,'akismet_error','1475051050'),
 (70,18,'akismet_history','a:3:{s:4:\"time\";d:1475051050.3614841;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (72,18,'akismet_delayed_moderation_email','1'),
 (73,19,'akismet_error','1475051137'),
 (74,19,'akismet_history','a:3:{s:4:\"time\";d:1475051137.2288771;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (76,19,'akismet_delayed_moderation_email','1'),
 (77,20,'akismet_error','1475389721'),
 (78,20,'akismet_history','a:3:{s:4:\"time\";d:1475389721.139827;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (80,20,'akismet_delayed_moderation_email','1'),
 (81,21,'akismet_error','1475398475'),
 (82,21,'akismet_history','a:3:{s:4:\"time\";d:1475398475.1554599;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (84,21,'akismet_delayed_moderation_email','1'),
 (85,22,'akismet_error','1475422761'),
 (86,22,'akismet_history','a:3:{s:4:\"time\";d:1475422761.2119589;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (88,22,'akismet_delayed_moderation_email','1'),
 (89,23,'akismet_error','1475429237'),
 (90,23,'akismet_history','a:3:{s:4:\"time\";d:1475429237.611161;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (92,23,'akismet_delayed_moderation_email','1'),
 (93,24,'akismet_error','1475436549'),
 (94,24,'akismet_history','a:3:{s:4:\"time\";d:1475436549.945827;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (96,24,'akismet_delayed_moderation_email','1'),
 (97,25,'akismet_error','1475436626'),
 (98,25,'akismet_history','a:3:{s:4:\"time\";d:1475436626.232198;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (100,25,'akismet_delayed_moderation_email','1'),
 (101,26,'akismet_error','1475440561'),
 (102,26,'akismet_history','a:3:{s:4:\"time\";d:1475440561.907563;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (104,26,'akismet_delayed_moderation_email','1'),
 (105,27,'akismet_error','1475516000'),
 (106,27,'akismet_history','a:3:{s:4:\"time\";d:1475516000.7557349;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (108,27,'akismet_delayed_moderation_email','1'),
 (109,28,'akismet_error','1476348226'),
 (110,28,'akismet_history','a:3:{s:4:\"time\";d:1476348226.9612391;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (112,28,'akismet_delayed_moderation_email','1'),
 (113,29,'akismet_error','1477021631'),
 (114,29,'akismet_history','a:3:{s:4:\"time\";d:1477021631.4282739;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (116,29,'akismet_delayed_moderation_email','1'),
 (117,30,'akismet_error','1477778504'),
 (118,30,'akismet_history','a:3:{s:4:\"time\";d:1477778504.8688669;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (120,30,'akismet_delayed_moderation_email','1'),
 (121,31,'akismet_error','1478528319'),
 (122,31,'akismet_history','a:3:{s:4:\"time\";d:1478528319.1711161;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (124,31,'akismet_delayed_moderation_email','1'),
 (125,32,'akismet_error','1480039148'),
 (126,32,'akismet_history','a:3:{s:4:\"time\";d:1480039148.852268;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (128,32,'akismet_delayed_moderation_email','1'),
 (129,33,'akismet_error','1480604790'),
 (130,33,'akismet_history','a:3:{s:4:\"time\";d:1480604790.0684941;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (132,33,'akismet_delayed_moderation_email','1'),
 (133,34,'akismet_error','1481051948'),
 (134,34,'akismet_history','a:3:{s:4:\"time\";d:1481051948.5078499;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (136,34,'akismet_delayed_moderation_email','1'),
 (137,35,'akismet_error','1481862521'),
 (138,35,'akismet_history','a:3:{s:4:\"time\";d:1481862521.0505171;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (140,35,'akismet_delayed_moderation_email','1'),
 (141,36,'akismet_error','1482067221'),
 (142,36,'akismet_history','a:3:{s:4:\"time\";d:1482067221.9937429;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (144,36,'akismet_delayed_moderation_email','1'),
 (145,37,'akismet_error','1482120949'),
 (146,37,'akismet_history','a:3:{s:4:\"time\";d:1482120949.4336131;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (148,37,'akismet_delayed_moderation_email','1'),
 (149,38,'akismet_error','1482569553'),
 (150,38,'akismet_history','a:3:{s:4:\"time\";d:1482569553.981214;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (152,38,'akismet_delayed_moderation_email','1'),
 (153,39,'akismet_error','1483559345'),
 (154,39,'akismet_history','a:3:{s:4:\"time\";d:1483559345.965786;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (156,39,'akismet_delayed_moderation_email','1'),
 (157,40,'akismet_error','1483588854'),
 (158,40,'akismet_history','a:3:{s:4:\"time\";d:1483588854.034302;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (160,40,'akismet_delayed_moderation_email','1'),
 (161,41,'akismet_error','1483676880'),
 (162,41,'akismet_history','a:3:{s:4:\"time\";d:1483676880.5631721;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (164,41,'akismet_delayed_moderation_email','1'),
 (165,42,'akismet_error','1483692047'),
 (166,42,'akismet_history','a:3:{s:4:\"time\";d:1483692047.350991;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (168,42,'akismet_delayed_moderation_email','1'),
 (169,43,'akismet_error','1483707260'),
 (170,43,'akismet_history','a:3:{s:4:\"time\";d:1483707260.096837;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (172,43,'akismet_delayed_moderation_email','1'),
 (173,44,'akismet_error','1483741926'),
 (174,44,'akismet_history','a:3:{s:4:\"time\";d:1483741926.400655;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (176,44,'akismet_delayed_moderation_email','1'),
 (177,45,'akismet_error','1483747447'),
 (178,45,'akismet_history','a:3:{s:4:\"time\";d:1483747447.598433;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (180,45,'akismet_delayed_moderation_email','1'),
 (181,46,'akismet_error','1483798668'),
 (182,46,'akismet_history','a:3:{s:4:\"time\";d:1483798668.1942141;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (184,46,'akismet_delayed_moderation_email','1'),
 (185,47,'akismet_error','1483808900'),
 (186,47,'akismet_history','a:3:{s:4:\"time\";d:1483808900.422029;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (188,47,'akismet_delayed_moderation_email','1'),
 (189,48,'akismet_error','1483839630'),
 (190,48,'akismet_history','a:3:{s:4:\"time\";d:1483839630.7740321;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (192,48,'akismet_delayed_moderation_email','1'),
 (193,49,'akismet_error','1483883703'),
 (194,49,'akismet_history','a:3:{s:4:\"time\";d:1483883703.9703479;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (196,49,'akismet_delayed_moderation_email','1'),
 (197,50,'akismet_error','1483951786'),
 (198,50,'akismet_history','a:3:{s:4:\"time\";d:1483951786.800776;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (200,50,'akismet_delayed_moderation_email','1'),
 (201,51,'akismet_error','1483994661'),
 (202,51,'akismet_history','a:3:{s:4:\"time\";d:1483994661.6668749;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (204,51,'akismet_delayed_moderation_email','1'),
 (205,52,'akismet_error','1484020611'),
 (206,52,'akismet_history','a:3:{s:4:\"time\";d:1484020611.5473659;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (208,52,'akismet_delayed_moderation_email','1'),
 (209,53,'akismet_error','1484029906'),
 (210,53,'akismet_history','a:3:{s:4:\"time\";d:1484029906.3680961;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (212,53,'akismet_delayed_moderation_email','1'),
 (213,54,'akismet_error','1484060561'),
 (214,54,'akismet_history','a:3:{s:4:\"time\";d:1484060561.6349809;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (216,54,'akismet_delayed_moderation_email','1'),
 (217,55,'akismet_error','1484067995'),
 (218,55,'akismet_history','a:3:{s:4:\"time\";d:1484067995.940552;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (220,55,'akismet_delayed_moderation_email','1'),
 (221,56,'akismet_error','1484092037'),
 (222,56,'akismet_history','a:3:{s:4:\"time\";d:1484092037.3023441;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (224,56,'akismet_delayed_moderation_email','1'),
 (225,57,'akismet_error','1484153563'),
 (226,57,'akismet_history','a:3:{s:4:\"time\";d:1484153563.1017449;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (228,57,'akismet_delayed_moderation_email','1'),
 (229,58,'akismet_error','1484986404'),
 (230,58,'akismet_history','a:3:{s:4:\"time\";d:1484986404.4572859;s:5:\"event\";s:11:\"check-error\";s:4:\"meta\";a:1:{s:8:\"response\";s:7:\"invalid\";}}'),
 (232,58,'akismet_delayed_moderation_email','1');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
