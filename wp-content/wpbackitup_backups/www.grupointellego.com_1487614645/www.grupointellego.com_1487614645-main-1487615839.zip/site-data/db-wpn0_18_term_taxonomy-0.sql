-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:21
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_18_term_taxonomy
-- Snapshot Table  : 1487614645_18_term_taxonomy
--
-- SQL    : SELECT * FROM wpn0_18_term_taxonomy LIMIT 0,10000
-- Offset : 0
-- Rows   : 109
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_18_term_taxonomy`
--
DROP TABLE  IF EXISTS `1487614645_18_term_taxonomy`;
CREATE TABLE `1487614645_18_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_18_term_taxonomy`
-- Number of rows: 109
--
INSERT INTO `1487614645_18_term_taxonomy` VALUES 
(1,1,'category','',0,4),
 (8,8,'nav_menu','',0,50),
 (9,9,'category','',0,0),
 (11,11,'category','',0,0),
 (13,13,'category','',0,0),
 (15,15,'category','',0,0),
 (17,17,'category','',0,0),
 (19,19,'category','',0,0),
 (21,21,'post_tag','',0,0),
 (23,23,'post_tag','',0,0),
 (25,25,'post_tag','',0,0),
 (27,27,'post_tag','',0,0),
 (29,29,'post_tag','',0,0),
 (31,31,'member-category','',0,0),
 (33,33,'member-category','',0,0),
 (35,35,'member-category','',0,0),
 (37,37,'member-category','',0,0),
 (39,39,'nav_menu','',0,0),
 (40,40,'category','',0,6),
 (41,41,'project-category','',0,10),
 (42,42,'project-category','',0,4),
 (43,43,'project-category','',0,5),
 (45,45,'project-category','',0,4),
 (47,47,'nav_menu','',0,4),
 (48,48,'category','',0,3),
 (49,49,'category','',0,0),
 (50,50,'member-category','',0,3),
 (51,51,'category','',0,0),
 (52,52,'category','',0,1),
 (53,53,'category','',0,0),
 (54,54,'project-category','',0,0),
 (55,55,'project-category','',0,0),
 (56,56,'project-category','',0,0),
 (57,57,'project-tag','',0,0),
 (58,58,'post_tag','',0,2),
 (59,59,'post_tag','',0,2),
 (60,60,'post_tag','',0,1),
 (61,61,'post_tag','',0,2),
 (62,62,'post_tag','',0,1),
 (63,63,'post_tag','',0,2),
 (64,64,'category','',0,0),
 (65,65,'post_tag','',0,0),
 (66,66,'post_tag','',0,1),
 (67,67,'post_tag','',0,1),
 (68,68,'project-tag','',0,7),
 (69,69,'project-tag','',0,1),
 (70,70,'project-tag','',0,1),
 (71,71,'project-tag','',0,1),
 (72,72,'project-tag','',0,6),
 (73,73,'project-tag','',0,2),
 (74,74,'project-tag','',0,2),
 (75,75,'project-tag','',0,5),
 (76,76,'project-tag','',0,1),
 (77,77,'project-tag','',0,4),
 (78,78,'project-tag','',0,1),
 (79,79,'category','',0,0),
 (80,80,'post_tag','',0,1),
 (81,81,'post_tag','',0,1),
 (82,82,'post_tag','',0,1),
 (83,83,'post_tag','',0,1),
 (84,84,'post_tag','',0,1),
 (85,85,'post_tag','',0,1),
 (86,86,'category','',0,0),
 (87,87,'category','',0,0),
 (88,88,'category','',0,0),
 (89,89,'category','',0,0),
 (90,90,'category','',0,0),
 (91,91,'post_tag','',0,1),
 (92,92,'post_tag','',0,1),
 (93,93,'category','',0,0),
 (94,94,'category','',0,0),
 (95,95,'category','',0,0),
 (96,96,'project-tag','',0,1),
 (97,97,'project-tag','',0,2),
 (98,98,'project-tag','',0,2),
 (99,99,'project-tag','',0,1),
 (100,100,'project-tag','',0,1),
 (101,101,'project-tag','',0,1),
 (102,102,'project-tag','',0,2),
 (103,103,'project-tag','',0,1),
 (104,104,'project-tag','',0,1),
 (105,105,'project-tag','',0,3),
 (106,106,'project-tag','',0,1),
 (107,107,'project-tag','',0,1),
 (108,108,'project-tag','',0,1),
 (109,109,'project-tag','',0,1),
 (110,110,'project-category','',0,0),
 (111,111,'project-tag','',0,1),
 (112,112,'project-tag','',0,2),
 (113,113,'project-category','',0,0),
 (114,114,'project-tag','',0,4),
 (115,115,'project-tag','',0,1),
 (116,116,'project-tag','',0,4),
 (117,117,'project-tag','',0,1),
 (118,118,'project-tag','',0,1),
 (119,119,'project-category','',0,1),
 (120,120,'project-tag','',0,1),
 (121,121,'project-tag','',0,3),
 (122,122,'project-tag','',0,1),
 (123,123,'project-category','',0,1),
 (124,124,'project-tag','',0,1),
 (125,125,'project-category','',0,1),
 (126,126,'project-category','',0,1),
 (127,127,'project-category','',0,1),
 (128,128,'project-tag','',0,1),
 (129,129,'project-tag','',0,1),
 (130,130,'project-tag','',0,1),
 (131,131,'project-tag','',0,1),
 (132,132,'category','',0,1);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
