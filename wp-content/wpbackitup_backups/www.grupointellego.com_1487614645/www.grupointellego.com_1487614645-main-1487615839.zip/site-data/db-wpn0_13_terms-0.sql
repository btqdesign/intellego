-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:21
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_13_terms
-- Snapshot Table  : 1487614645_13_terms
--
-- SQL    : SELECT * FROM wpn0_13_terms LIMIT 0,10000
-- Offset : 0
-- Rows   : 107
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_13_terms`
--
DROP TABLE  IF EXISTS `1487614645_13_terms`;
CREATE TABLE `1487614645_13_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



--
-- Data for table `wpn0_13_terms`
-- Number of rows: 107
--
INSERT INTO `1487614645_13_terms` VALUES 
(1,'Sin categoría','sin-categoria',0),
 (8,'Main Menu','main-menu',0),
 (9,'Blogs','blogs',0),
 (11,'Construction','construction',0),
 (13,'Design Build','design-build',0),
 (15,'Development','development',0),
 (17,'Houses','houses',0),
 (19,'Projects','projects',0),
 (21,'Blogs','blogs',0),
 (23,'Construction','construction',0),
 (25,'Design Build','design-build',0),
 (27,'Development','development',0),
 (29,'Houses','houses',0),
 (31,'Beginner','beginner',0),
 (33,'Builders','builders',0),
 (35,'Construction','construction',0),
 (37,'Designing','designing',0),
 (39,'Widget Menu','widget-menu',0),
 (40,'Noticias','noticias',0),
 (41,'Artículos','articulos',0),
 (42,'Brochures','brochures',0),
 (43,'Casos de éxito','casos-de-exito',0),
 (45,'Videos','videos',0),
 (47,'Footer Menu','footer-menu',0),
 (48,'Vacantes','vacantes',0),
 (49,'Sin categoría @en','sin-categoria-en',0),
 (50,'equipo mexico','equipo-mexico',0),
 (51,'SAP','sap',0),
 (52,'Categoria de prueba','categoria-de-prueba',0),
 (53,'Prueba','prueba',0),
 (54,'Expansión','expansion',0),
 (55,'Felipe Labbé','felipe-labbe',0),
 (56,'Intellego','intellego',0),
 (57,'Logros','logros',0),
 (58,'Multilatinas','multilatinas',0),
 (59,'Reconocimientos','reconocimientos',0),
 (60,'Noticias','noticias-en',0),
 (61,'Noticias','noticias-en-2',0),
 (62,'Endeavor','endeavor-en',0),
 (63,'Felipe Labbé','felipe-labbe-en',0),
 (64,'Logros','logros-en',0),
 (65,'Noticias','noticias-en-3',0),
 (66,'Noticias','noticias-en-4',0),
 (67,'Prueba','prueba-en',0),
 (68,'Business Intelligence','business-intelligence',0),
 (69,'Information Management Strategy','information-management-strategy',0),
 (70,'Data Warehouse','data-warehouse',0),
 (71,'ETL','etl',0),
 (72,'Information Management','information-management',0),
 (73,'Data Management','data-management',0),
 (74,'Tecnologías de la Información','tecnologias-de-la-informacion',0),
 (75,'advanced analytics','advanced-analytics',0),
 (76,'Customer Relationship Management','customer-relationship-management',0),
 (77,'Optimizar Procesos','optimizar-procesos',0),
 (78,'ROI','roi',0),
 (79,'Noticias','noticias-en-5',0),
 (80,'Expansión','expansion-en',0),
 (81,'Intellego','intellego-en',0),
 (82,'Multilatinas','multilatinas-en',0),
 (83,'Reconocimientos','reconocimientos-en',0),
 (84,'Noticias','noticias-en-6',0),
 (85,'Noticias','noticias-en-7',0),
 (86,'Noticias','noticias-en-8',0),
 (87,'Noticias','noticias-en-9',0),
 (88,'Noticias','noticias-en-10',0),
 (89,'Acknowledgments','acknowledgments',0),
 (90,'Awards','awards',0),
 (91,'Noticias','noticias-en-11',0),
 (92,'Noticias','noticias-en-12',0),
 (93,'Noticias','noticias-en-13',0),
 (94,'Noticias','noticias-en-14',0),
 (95,'Noticias','noticias-en-15',0),
 (96,'Noticias','noticias-en-16',0),
 (97,'Notas de Prensa','notas-de-prensa-en',0),
 (98,'Noticias','noticias-en-17',0),
 (99,'Cloud','cloud-en',0),
 (100,'Cloud Solutions','cloud-solutions-en',0),
 (101,'Notas de Prensa','notas-de-prensa-en',0),
 (102,'Notas de Prensa','notas-de-prensa',0),
 (103,'Business Service Management','business-service-management',0),
 (104,'Extension','extension',0),
 (105,'Tecnología de la Información','tecnologia-de-la-informacion',0),
 (106,'News','news-en',0),
 (107,'Press','press',0),
 (108,'News','news-en-2',0),
 (109,'Press','press-2',0),
 (110,'Business Service Management','business-service-management-en',0),
 (111,'Extension','extension-en',0),
 (112,'Tecnología de la Información','tecnologia-de-la-informacion-en',0),
 (113,'BMC','bmc',0),
 (114,'Monitoreo','monitoreo',0),
 (115,'App','app',0),
 (116,'App Development','app-development',0),
 (117,'Desarrollo de Software','desarrollo-de-software',0),
 (118,'Aplicaciones','aplicaciones',0),
 (119,'Apps','apps',0),
 (120,'Economía','economia',0),
 (121,'Enterprise Performance Management','enterprise-performance-management',0),
 (122,'Regulaciones Fiscales','regulaciones-fiscales',0),
 (123,'Seguros','seguros',0),
 (124,'Big Data','big-data',0),
 (125,'Big Data Analytics','big-data-analytics',0),
 (126,'Geoanalitica','geoanalitica',0),
 (127,'Gobierno Digital','gobierno-digital',0),
 (128,'Gobierno Sin Papel','gobierno-sin-papel',0),
 (129,'Artículos 2','articulos-2',0),
 (130,'videos','videos',0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
