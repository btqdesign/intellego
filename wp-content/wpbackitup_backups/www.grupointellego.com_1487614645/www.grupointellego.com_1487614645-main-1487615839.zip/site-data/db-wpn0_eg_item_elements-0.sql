-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:26
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_eg_item_elements
-- Snapshot Table  : 1487614645_eg_item_elements
--
-- SQL    : SELECT * FROM wpn0_eg_item_elements LIMIT 0,10000
-- Offset : 0
-- Rows   : 2
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_eg_item_elements`
--
DROP TABLE  IF EXISTS `1487614645_eg_item_elements`;
CREATE TABLE `1487614645_eg_item_elements` (
  `id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `settings` mediumtext NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `handle` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_eg_item_elements`
-- Number of rows: 2
--
INSERT INTO `1487614645_eg_item_elements` VALUES 
(1,'advanced','advanced','{\"source\":\"text\",\"source-post\":\"title\",\"source-separate\":\",\",\"source-function\":\"link\",\"source-meta\":\"\",\"limit-type\":\"none\",\"limit-num\":\"10\",\"source-icon\":\"\",\"source-text-style-disable\":\"false\",\"source-text\":\"Ir a Advanced Analytics\",\"enable-hover\":\"false\",\"font-size\":\"13\",\"line-height\":\"20\",\"color\":\"#ffffff\",\"0\":\"Predeterminado\",\"font-family\":\"\",\"font-weight\":\"400\",\"text-decoration\":\"none\",\"font-style\":\"false\",\"text-transform\":\"uppercase\",\"position\":\"relative\",\"align\":\"t_l\",\"absolute-unit\":\"px\",\"top-bottom\":\"0\",\"left-right\":\"0\",\"display\":\"inline-block\",\"text-align\":\"center\",\"float\":\"none\",\"clear\":\"both\",\"margin\":[\"0\",\"0\",\"0\",\"0\"],\"padding\":[\"0\",\"0\",\"0\",\"0\"],\"background-color\":\"#ffffff\",\"bg-alpha\":\"0\",\"shadow-color\":\"#000000\",\"shadow-alpha\":\"100\",\"box-shadow\":[\"0\",\"0\",\"0\",\"0\"],\"border\":[\"0\",\"0\",\"0\",\"0\"],\"border-radius\":[\"0\",\"0\",\"0\",\"0\"],\"border-radius-unit\":\"px\",\"border-color\":\"transparent\",\"border-style\":\"none\",\"font-size-hover\":\"13\",\"line-height-hover\":\"14\",\"color-hover\":\"#ffffff\",\"font-family-hover\":\"\",\"font-weight-hover\":\"300\",\"text-decoration-hover\":\"none\",\"font-style-hover\":\"false\",\"text-transform-hover\":\"none\",\"background-color-hover\":\"#ffffff\",\"bg-alpha-hover\":\"15\",\"shadow-color-hover\":\"#000000\",\"shadow-alpha-hover\":\"100\",\"box-shadow-hover\":[\"0\",\"0\",\"0\",\"0\"],\"border-hover\":[\"0\",\"0\",\"0\",\"0\"],\"border-radius-hover\":[\"0\",\"0\",\"0\",\"0\"],\"border-radius-unit-hover\":\"px\",\"border-color-hover\":\"transparent\",\"border-style-hover\":\"none\",\"hideunder\":\"0\",\"hideunderheight\":\"0\",\"hidetype\":\"visibility\",\"hide-on-video\":\"false\",\"show-on-sale\":\"false\",\"show-if-featured\":\"false\",\"transition\":\"flyright\",\"transition-type\":\"\",\"delay\":\"0\",\"link-type\":\"url\",\"url-link\":\"\\/big-data\",\"meta-link\":\"\",\"javascript-link\":\"\",\"link-target\":\"_self\",\"tag-type\":\"div\",\"force-important\":\"false\"}'),
 (2,'SAP','sap','{\"source\":\"text\",\"source-post\":\"title\",\"source-separate\":\",\",\"source-function\":\"link\",\"source-meta\":\"\",\"limit-type\":\"none\",\"limit-num\":\"10\",\"source-icon\":\"\",\"source-text-style-disable\":\"false\",\"source-text\":\"Ir a Alianzas SAP\",\"enable-hover\":\"false\",\"font-size\":\"13\",\"line-height\":\"20\",\"color\":\"#ffffff\",\"0\":\"Predeterminado\",\"font-family\":\"\",\"font-weight\":\"400\",\"text-decoration\":\"none\",\"font-style\":\"false\",\"text-transform\":\"uppercase\",\"position\":\"relative\",\"align\":\"t_l\",\"absolute-unit\":\"px\",\"top-bottom\":\"0\",\"left-right\":\"0\",\"display\":\"inline-block\",\"text-align\":\"center\",\"float\":\"none\",\"clear\":\"both\",\"margin\":[\"0\",\"0\",\"0\",\"0\"],\"padding\":[\"0\",\"0\",\"0\",\"0\"],\"background-color\":\"#ffffff\",\"bg-alpha\":\"0\",\"shadow-color\":\"#000000\",\"shadow-alpha\":\"100\",\"box-shadow\":[\"0\",\"0\",\"0\",\"0\"],\"border\":[\"0\",\"0\",\"0\",\"0\"],\"border-radius\":[\"0\",\"0\",\"0\",\"0\"],\"border-radius-unit\":\"px\",\"border-color\":\"transparent\",\"border-style\":\"none\",\"font-size-hover\":\"13\",\"line-height-hover\":\"14\",\"color-hover\":\"#ffffff\",\"font-family-hover\":\"\",\"font-weight-hover\":\"300\",\"text-decoration-hover\":\"none\",\"font-style-hover\":\"false\",\"text-transform-hover\":\"none\",\"background-color-hover\":\"#ffffff\",\"bg-alpha-hover\":\"15\",\"shadow-color-hover\":\"#000000\",\"shadow-alpha-hover\":\"100\",\"box-shadow-hover\":[\"0\",\"0\",\"0\",\"0\"],\"border-hover\":[\"0\",\"0\",\"0\",\"0\"],\"border-radius-hover\":[\"0\",\"0\",\"0\",\"0\"],\"border-radius-unit-hover\":\"px\",\"border-color-hover\":\"transparent\",\"border-style-hover\":\"none\",\"hideunder\":\"0\",\"hideunderheight\":\"0\",\"hidetype\":\"visibility\",\"hide-on-video\":\"false\",\"show-on-sale\":\"false\",\"show-if-featured\":\"false\",\"transition\":\"flyright\",\"transition-type\":\"\",\"delay\":\"0\",\"link-type\":\"url\",\"url-link\":\"\\/big-data\",\"meta-link\":\"\",\"javascript-link\":\"\",\"link-target\":\"_self\",\"tag-type\":\"div\",\"force-important\":\"false\"}');

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
