-- ------------------------------------------------------
-- ------------------------------------------------------
--
-- WPBackItUp Database Export 
--
-- Created: 2017/02/21 on 12:25
--
-- Database : wpn_production
--
-- Backup   Table  : wpn0_21_icl_translate
-- Snapshot Table  : 1487614645_21_icl_translate
--
-- SQL    : SELECT * FROM wpn0_21_icl_translate LIMIT 0,10000
-- Offset : 0
-- Rows   : 5
-- ------------------------------------------------------
-- ------------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40101 SET SESSION sql_mode = '' */;

--
-- Table structure for table `1487614645_21_icl_translate`
--
DROP TABLE  IF EXISTS `1487614645_21_icl_translate`;
CREATE TABLE `1487614645_21_icl_translate` (
  `tid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_id` bigint(20) unsigned NOT NULL,
  `content_id` bigint(20) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `field_type` varchar(128) NOT NULL,
  `field_format` varchar(16) NOT NULL,
  `field_translate` tinyint(4) NOT NULL,
  `field_data` longtext NOT NULL,
  `field_data_translated` longtext NOT NULL,
  `field_finished` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`),
  KEY `job_id` (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;



--
-- Data for table `wpn0_21_icl_translate`
-- Number of rows: 5
--
INSERT INTO `1487614645_21_icl_translate` VALUES 
(1,1,0,'2015-03-23 16:43:19','title','base64',1,'wqFIb2xhIG11bmRvIQ==','',0),
 (2,1,0,'2015-03-23 16:43:19','body','base64',1,'QmllbnZlbmlkbyBhIFdvcmRQcmVzcy4gRXN0YSBlcyB0dSBwcmltZXJhIGVudHJhZGEuIEVkw610YWxhIG8gYsOzcnJhbGEsIMKheSBjb21pZW56YSBhIHB1YmxpY2FyIS4=','',0),
 (3,1,0,'2015-03-23 16:43:19','original_id','',0,'1','',0),
 (4,1,0,'2015-03-23 16:43:19','categories','csv_base64',1,'\"U2luIGNhdGVnb3LDrWE=\"','',0),
 (5,1,0,'2015-03-23 16:43:19','category_ids','',0,'1','',0);

SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
